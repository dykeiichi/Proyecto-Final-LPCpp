#include <iostream>
#include "Credito.h"

using namespace std;

void Credito::depositar(long double val){
    if (val <= (getSaldo() * -1) && val > 0){
        setSaldo(getSaldo() + val);
        _credito_disponible += val;
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        cout<<"Ha ocurrido un error"<<endl;
        if( val > (getSaldo() * -1) ){
            cout<<"No puede depositar mas de su adeudo"<<endl;
        }
        if(!(val > 0)){
            cout<<"Valor no valido"<<endl;
        }
        throw 11808;
    }
}

void Credito::retirar(long double val){
    if (val <= _credito_disponible && val > 0){
        setSaldo(getSaldo() - val);
        _credito_disponible -= val;
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        cout<<"Ha ocurrido un error"<<endl;
        if( val > _credito_disponible ){
            cout<<"No tiene suficientes fondos"<<endl;
        }
        if(!(val > 0)){
            cout<<"Valor no valido"<<endl;
        }
        throw 11808;
    }
}

void Credito::leer(Cuenta cuenta, long double creditoDis){
    this->setNumeroCuenta(cuenta.getNumeroCuenta());
    this->setTitular(cuenta.getTitular());
    this->setSaldo(cuenta.getSaldo());
    this->_credito_disponible = creditoDis;
}

bool Credito::operator<(Credito cr){
    if (this->getNumeroCuenta() < cr.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Credito::operator>(Credito cr){
    if (this->getNumeroCuenta() > cr.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Credito::operator==(Credito cr){
    if (this->getNumeroCuenta() == cr.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Credito::operator<=(Credito cr){
    if (this->getNumeroCuenta() <= cr.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Credito::operator>=(Credito cr){
    if (this->getNumeroCuenta() >= cr.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Credito::operator!=(Credito cr){
    if (this->getNumeroCuenta() != cr.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}
