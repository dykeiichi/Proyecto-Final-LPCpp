#include "Credito.h"

Credito::Credito()
{
    //ctor
}
