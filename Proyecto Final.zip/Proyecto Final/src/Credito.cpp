#include <iostream>
#include <iomanip>
#include "Credito.h"

using namespace std;

Credito::Credito(){
    this->setTipo(false);
}

Credito::Credito(Cuenta &val1, long creditoDis):Cuenta(val1.getNumeroCuenta(), val1.getTitular(), val1.getSaldo(), false){
    _credito_disponible = creditoDis;
}

void Credito::set_Credito_Maximo(long double val){
    _credito_disponible = val + getSaldo();
}

long double Credito::get_Credito_Disponible(){
    return _credito_disponible;
}

void Credito::depositar(long double val){
    if (val <= (getSaldo() * -1) && val > 0){
        setSaldo(getSaldo() + val);
        _credito_disponible += val;
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        cout<<"Ha ocurrido un error"<<endl;
        if( val > (getSaldo() * -1) ){
            cout<<"No puede depositar mas de su adeudo"<<endl;
        }
        if(!(val > 0)){
            cout<<"Valor no valido"<<endl;
        }
        throw 11808;
    }
}

void Credito::retirar(long double val){
    if (val <= _credito_disponible && val > 0){
        setSaldo(getSaldo() - val);
        _credito_disponible -= val;
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        cout<<"Ha ocurrido un error"<<endl;
        if( val > _credito_disponible ){
            cout<<"No tiene suficientes fondos"<<endl;
        }
        if(!(val > 0)){
            cout<<"Valor no valido"<<endl;
        }
        throw 11808;
    }
}

bool Credito::operator<(Credito cr){
    if (this->getNumeroCuenta() < cr.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Credito::operator>(Credito cr){
    if (this->getNumeroCuenta() > cr.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Credito::operator==(Credito cr){
    if (this->getNumeroCuenta() == cr.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Credito::operator<=(Credito cr){
    if (this->getNumeroCuenta() <= cr.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Credito::operator>=(Credito cr){
    if (this->getNumeroCuenta() >= cr.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Credito::operator!=(Credito cr){
    if (this->getNumeroCuenta() != cr.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

string Credito::guardar(){
    return "" + to_string(getNumeroCuenta()) + '@' + to_string(_credito_disponible) + "\n";
}

void Credito::leer(Cuenta cuenta, long double creditoDis){
    this->setNumeroCuenta(cuenta.getNumeroCuenta());
    this->setTitular(cuenta.getTitular());
    this->setSaldo(cuenta.getSaldo());
    this->_credito_disponible = creditoDis;
}

ostream& operator<<(ostream& os, Credito cr){

    string activo = "";
    if (cr.getActivo() == true){
        activo = "Se encuentra: Activa";
    }else{
        activo = "Se encuentra: Inactiva";
    }

    string saldo = "";
    if (cr.getSaldo() != 0 ){
        saldo = to_string(( cr.getSaldo()) * (-1) );
    }else{
        saldo = to_string( cr.getSaldo() );
    }


/*                                Lo que se manda al os pero ordenado
    cout<<"\n\n\n\n            "<<setw(56)<<"--------------------------------------------------------\n";
    cout<<"            "<<setw(56)<<( "Numero de Cuenta: " + to_string(cr.getNumeroCuenta()) + "\n" );
    cout<<"            "<<setw(56)<<( "Saldo: " + saldo + "\n" );
    cout<<"            "<<setw(56)<<"Tipo de cuenta: Credito\n";
    cout<<"            "<<setw(56)<<( activo + "\n\n" );

    cout<<"            "<<setw(56)<<( "ID: " + to_string(cr.getTitular().getID()) + "\n");
    cout<<"            "<<setw(56)<<( "Nombre: " + cr.getTitular().getNombre() + "\n" );
    cout<<"            "<<setw(56)<<( "Direccion: " + cr.getTitular().getDireccion() + "\n" );
    cout<<"            "<<setw(56)<<( "RFC: " + cr.getTitular().getRFC() + "\n" );
    cout<<"            "<<setw(56)<<( "Credito Disponible: " + to_string(cr.get_Credito_Disponible()) + "\n" );
    cout<<"            "<<setw(56)<<( "Credito total: " + to_string(cr.get_Credito_Disponible() - cr.getSaldo()) + "\n");
    cout<<"            "<<setw(56)<<setw(56)<<"--------------------------------------------------------\n";
*/
    return (os <<"\n\n\n\n            "<<setw(56)<<"--------------------------------------------------------\n"<<"            "<<setw(56)<<( "Numero de Cuenta: " + to_string(cr.getNumeroCuenta()) + "\n" )<<"            "<<setw(56)<<( "Saldo: " + saldo + "\n" )<<"            "<<setw(56)<<"Tipo de cuenta: Credito\n"<<"            "<<setw(56)<<( activo + "\n\n" )<<"            "<<setw(56)<<( "ID: " + to_string(cr.getTitular().getID()) + "\n")<<"            "<<setw(56)<<( "Nombre: " + cr.getTitular().getNombre() + "\n" )<<"            "<<setw(56)<<( "Direccion: " + cr.getTitular().getDireccion() + "\n" )<<"            "<<setw(56)<<( "RFC: " + cr.getTitular().getRFC() + "\n" )<<"            "<<setw(56)<<( "Credito Disponible: " + to_string(cr.get_Credito_Disponible()) + "\n" )<<"            "<<setw(56)<<( "Credito total: " + to_string(cr.get_Credito_Disponible() - cr.getSaldo()) + "\n")<<"            "<<setw(56)<<setw(56)<<"--------------------------------------------------------\n");
}
