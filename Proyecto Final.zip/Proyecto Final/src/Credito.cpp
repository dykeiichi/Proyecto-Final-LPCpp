#include <iostream>
#include <fstream>
#include "Credito.h"
#include "Cliente.h"

using namespace std;

void Credito::depositar(long double val){
    if (0 >= (getSaldo() + val) && val > 0){
        setSaldo(getSaldo() + val);
        _credito_disponible += val;
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        cout<<"Ha ocurrido un error"<<endl;
        if(!(0 >= (getSaldo() + val))){
            cout<<"El deposito maximo corresponde a la cantidad que debe"<<endl;
        }
        if(!(val > 0)){
            cout<<"Valor no valido"<<endl;
        }
    }
}

void Credito::retirar(long double val){
    if (val <= _credito_disponible && val > 0){
        setSaldo(getSaldo() - val);
        _credito_disponible -= val;
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        if (!(val <= _credito_disponible)){
            cout<<"No cuenta con suficeinte credito"<<endl;
        }
        if (!(val > 0)){
            cout<<"Valor no valido"<<endl;
        }
    }
}

void Credito::toString(){
    cout<<"-------------------------------"<<endl;
    cout<<"Numero de Cuenta: "<<getNumCuenta()<<endl;
    cout<<"Saldo: "<<getSaldo()<<endl;
    cout<<"Credito Disponible: "<<_credito_disponible<<endl;
    Cliente cliente = getTitular();
    cliente.verInformacion();
}
