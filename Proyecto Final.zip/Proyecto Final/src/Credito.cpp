#include <iostream>
#include <fstream>
#include "Credito.h"
#include "Cliente.h"

using namespace std;

void Credito::depositar(long double val){
    if (0 >= (getSaldo() + val) && val > 0){
        setSaldo(getSaldo() + val);
        _credito_disponible += val;
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        cout<<"Ha ocurrido un error"<<endl;
        if(!(0 >= (getSaldo() + val))){
            cout<<"El deposito maximo corresponde a la cantidad que debe"<<endl;
        }
        if(!(val > 0)){
            cout<<"Valor no valido"<<endl;
        }
    }
}

void Credito::retirar(long double val){
    if (val <= _credito_disponible && val > 0){
        setSaldo(getSaldo() - val);
        _credito_disponible -= val;
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        if (!(val <= _credito_disponible)){
            cout<<"No cuenta con suficeinte credito"<<endl;
        }
        if (!(val > 0)){
            cout<<"Valor no valido"<<endl;
        }
    }
}

void Credito::toString(){
    cout<<"-------------------------------"<<endl;
    cout<<"Numero de Cuenta: "<<getNumCuenta()<<endl;
    cout<<"Saldo: "<<getSaldo()<<endl;
    cout<<"Credito Disponible: "<<_credito_disponible<<endl;
    Cliente cliente = getTitular();
    cliente.verInformacion();
}

void Credito::guardar(ofstream& salida){
    salida<<getNumCuenta()<<","<<_credito_disponible<<endl;
}

bool Credito::leer(ifstream& archivo){
    const int SIZE = 500;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, ',');
    if (!archivo.good()){
        return false;
    }else{
        numCuenta = atol(buffer);

        archivo.getline(buffer, SIZE, '\n');
        _credito_disponible = atol(buffer);

        if (getNumCuenta() != 0){
            ifstream archivo_in;
            archivo_in.open("Cuentas.txt");
            Cuenta::leer(archivo_in, numCuenta);
        }

        return true;
    }
}

bool Credito::leer(ifstream& archivo, long cuenta){
    const int SIZE = 500;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, ',');
    if (!archivo.good()){
        return false;
    }else{
        do{
            numCuenta = atol(buffer);
            archivo.getline(buffer, SIZE, '\n');
            _credito_disponible = atol(buffer);

            if (numCuenta != 0){
                ifstream archivo_in;
                archivo_in.open("Cuentas.txt");
                Cuenta::leer(archivo_in, cuenta);
            }
            archivo.getline(buffer, SIZE, ',');
        }while(numCuenta != cuenta);

        _credito_disponible = 50000 - saldo;

        return true;
    }
}
