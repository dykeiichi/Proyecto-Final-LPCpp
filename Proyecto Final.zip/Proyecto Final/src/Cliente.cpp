#include "Cliente.h"
#include <iostream>
#include <fstream>

#include <unistd.h>
#include <windows.h>

long Cliente::val = 1001;

Cliente::Cliente()
{

}

Cliente::Cliente(string nombre, string direccion, string RFC){
    setNombre(nombre);
    setDireccion(direccion);
    setRFC(RFC);
    setVal();
}

void Cliente::verInformacion(){
    cout<<"-------------------------------"<<endl;
    cout<<"ID: "<<ID<<endl;
    cout<<"Nombre: "<<nombre<<endl;
    cout<<"Direccion: "<<direccion<<endl;
    cout<<"RFC: "<<RFC<<endl;
    cout<<"-------------------------------"<<endl;
}
