#include "Cliente.h"
#include <iostream>
#include <fstream>

long Cliente::val = 1001;

Cliente::Cliente()
{

}

Cliente::Cliente(string nombre, string direccion, string RFC){
    setNombre(nombre);
    setDireccion(direccion);
    setRFC(RFC);
    setVal();
}

void Cliente::guardar(ofstream& salida){

    salida<<"Cliente@"<<ID<<","<<nombre<<","<<direccion<<","<<RFC<<endl;
}

bool Cliente::leer(ifstream& archivo){
    const int SIZE = 500;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, '@');
    if (!archivo.good()){
        return false;
    }else{
        archivo.getline(buffer, SIZE, ',');
        ID = atol(buffer);

        archivo.getline(buffer, SIZE, ',');
        nombre = buffer;

        archivo.getline(buffer, SIZE, ',');
        direccion = buffer;

        archivo.getline(buffer, SIZE, '\n');
        RFC = buffer;

        return true;
    }
}

bool Cliente::leer(long id_In){
    ifstream archivo;

    archivo.open("Clientes.txt");
    const int SIZE = 500;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, '@');
    if (!archivo.good()){
        return false;
    }else{
        do{
            archivo.getline(buffer, SIZE, ',');
            ID = atol(buffer);

            archivo.getline(buffer, SIZE, ',');
            nombre = buffer;

            archivo.getline(buffer, SIZE, ',');
            direccion = buffer;

            archivo.getline(buffer, SIZE, '\n');
            RFC = buffer;

            if (ID == 0){
                throw 1;
            }
            archivo.getline(buffer, SIZE, ',');
        }while (ID != id_In);

        return true;
    }
}

void Cliente::verInformacion(){
    cout<<"-------------------------------"<<endl;
    cout<<"ID: "<<ID<<endl;
    cout<<"Nombre: "<<nombre<<endl;
    cout<<"Direccion: "<<direccion<<endl;
    cout<<"RFC: "<<RFC<<endl;
    cout<<"-------------------------------"<<endl;
}
