#include "Cliente.h"
#include <iostream>
#include <fstream>

long Cliente::val = 1000;

Cliente::Cliente(){

}

Cliente::Cliente(string nombre, string direccion, string RFC){
    setNombre(nombre);
    setDireccion(direccion);
    setRFC(RFC);
    setVal();
    setID();
}

void Cliente::setThis(Cliente ThisCliente){
    this->ID = ThisCliente.ID;
    this->nombre = ThisCliente.nombre;
    this->direccion = ThisCliente.direccion;
    this->RFC = ThisCliente.RFC;
}

void Cliente::verInformacion(){
    cout<<"ID: "<<ID<<endl;
    cout<<"Nombre: "<<nombre<<endl;
    cout<<"Direccion: "<<direccion<<endl;
    cout<<"RFC: "<<RFC<<endl;
}

void Cliente::leer(long ID, string nombre, string direccion, string RFC){
    this->ID = ID;
    this->nombre = nombre;
    this->direccion = direccion;
    this->RFC = RFC;
}

bool Cliente::operator<(Cliente cl){
    if (this->ID < cl.getID()){
        return true;
    }else{
        return false;
    }
}

bool Cliente::operator>(Cliente cl){
    if (this->ID > cl.getID()){
        return true;
    }else{
        return false;
    }
}

bool Cliente::operator==(Cliente cl){
    if (this->ID == cl.getID()){
        return true;
    }else{
        return false;
    }
}

bool Cliente::operator<=(Cliente cl){
    if (this->ID <= cl.getID()){
        return true;
    }else{
        return false;
    }
}

bool Cliente::operator>=(Cliente cl){
    if (this->ID >= cl.getID()){
        return true;
    }else{
        return false;
    }
}

bool Cliente::operator!=(Cliente cl){
    if (this->ID != cl.getID()){
        return true;
    }else{
        return false;
    }
}
