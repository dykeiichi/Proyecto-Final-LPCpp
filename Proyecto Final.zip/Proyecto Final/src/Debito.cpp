#include <iostream>
#include <iomanip>
#include "Debito.h"
#include "Tiempo.h"

using namespace std;

Debito::Debito(){
    this->setTipo(true);
    Tiempo tmp = Tiempo();
    this->anio = tmp.getAnio();
    this->mes = tmp.getMes();
    this->dia = tmp.getDia();
}

Debito::Debito(Cuenta &val1, double retiroMaximo):Cuenta(val1.getNumeroCuenta(), val1.getTitular(), val1.getSaldo(), true){
    this->retiroMaximo = retiroMaximo;
    retiroRestante = retiroMaximo;
}

void Debito::depositar(long double val){
    if ( val > 0){
        if (depositoMes > 25000){
            setSaldo(getSaldo() + val);
            setSaldo( getSaldo() - (depositoMes * 0.2) );
            depositoMes = -1;
        }else{
            if (depositoMes >= 0){
                setSaldo(getSaldo() + val);
                depositoMes += val;
                if (depositoMes > 25000){
                    setSaldo( getSaldo() - (depositoMes * 0.2) );
                    depositoMes = -1;
                }
            }else{
                if (depositoMes == -1){
                    setSaldo(getSaldo() + (val * 0.8 ));
                }
            }
        }
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        cout<<"Ha ocurrido un error"<<endl;
        if(!(val > 0)){
            cout<<"Valor no valido"<<endl;
        }
        throw 11808;
    }
}

void Debito::retirar(long double val){

    validarRetiro();

    if (val <= getSaldo() && val > 0 && val <= retiroRestante){
        setSaldo(getSaldo() - val);
        retiroRestante -= val;
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        cout<<"Ha ocurrido un error"<<endl;
        if( val > getSaldo() ){
            cout<<"No dispone de suficientes fondos"<<endl;
        }
        if(!(val > 0)){
            cout<<"Valor no valido"<<endl;
        }
        if (val > retiroMaximo){
            cout<<"No puede retirar esa cantidad en un solo dia"<<endl;
        }
        if (val > retiroRestante && val <= retiroMaximo){
            cout<<"No puede retirar esa cantidad le dia de hoy"<<endl;
        }
        throw 11808;
    }
}

void Debito::setRetiroMaximo(double val){
    double aux = val - retiroMaximo;
    this->retiroMaximo = val;
    retiroRestante += aux;
}

double Debito::getRetiroMaximo(){
    return retiroMaximo;
}

double Debito::getRetiroRestante(){
    return retiroRestante;
}

double Debito::getDepositoMes(){
    return depositoMes;
}

void Debito::restart(){
    depositoMes = 0;
}

string Debito::guardar(){
    return "" + to_string(getNumeroCuenta()) + '@' + to_string(retiroMaximo) + '@' + to_string(retiroRestante) + '@' + to_string(depositoMes) + '@' + to_string(dia) + '@' + to_string(mes) + '@' + to_string(anio) + "\n";
}

void Debito::leer(Cuenta cuenta, double retiroMaximo, double retiroRestante, double depositoMes, int dia, int mes, int anio){
    this->setNumeroCuenta(cuenta.getNumeroCuenta());
    this->setTitular(cuenta.getTitular());
    this->setSaldo(cuenta.getSaldo());
    this->retiroMaximo = retiroMaximo;
    this->retiroRestante = retiroRestante;
    this->depositoMes = depositoMes;
    this->dia = dia;
    this->mes = mes;
    this->anio = anio;
}

void Debito::validarRetiro(){
    Tiempo tmp = Tiempo();
    int aniotmp = tmp.getAnio();
    int mestmp = tmp.getMes();
    int diatmp = tmp.getDia();

    if ((aniotmp != this->anio || mestmp != this->mes) || diatmp != this->dia){
        this->anio = tmp.getAnio();
        this->mes = tmp.getMes();
        this->dia = tmp.getDia();
        retiroRestante = retiroMaximo;
    }
}

bool Debito::operator<(Debito de){
    if (this->getNumeroCuenta() < de.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Debito::operator>(Debito de){
    if (this->getNumeroCuenta() > de.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Debito::operator==(Debito de){
    if (this->getNumeroCuenta() == de.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Debito::operator<=(Debito de){
    if (this->getNumeroCuenta() <= de.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Debito::operator>=(Debito de){
    if (this->getNumeroCuenta() >= de.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Debito::operator!=(Debito de){
    if (this->getNumeroCuenta() != de.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

ostream& operator<<(ostream& os, Debito de){

    string activo = "";
    if (de.getActivo() == true){
        activo = "Se encuentra: Activa";
    }else{
        activo = "Se encuentra: Inactiva";
    }

/*                                Lo que se manda al os pero ordenado
    cout<<"\n\n\n\n            "<<setw(56)<<"--------------------------------------------------------\n";
    cout<<"            "<<setw(56)<<( "Numero de Cuenta: " + to_string(de.getNumeroCuenta()) + "\n" );
    cout<<"            "<<setw(56)<<( "Saldo: " + to_string(de.getSaldo()) + "\n" );
    cout<<"            "<<setw(56)<<"Tipo de cuenta: Debito\n";
    cout<<"            "<<setw(56)<<( activo + "\n\n" );

    cout<<"            "<<setw(56)<<( "ID: " + to_string(de.getTitular().getID()) + "\n");
    cout<<"            "<<setw(56)<<( "Nombre: " + de.getTitular().getNombre() + "\n" );
    cout<<"            "<<setw(56)<<( "Direccion: " + de.getTitular().getDireccion() + "\n" );
    cout<<"            "<<setw(56)<<( "RFC: " + de.getTitular().getRFC() + "\n" );
    cout<<"            "<<setw(56)<<( "Retiro Maximo por Dia: " + to_string(de.getRetiroMaximo()) + "\n" );
    cout<<"            "<<setw(56)<<( "Puede retirar el dia de hoy: " + to_string(de.getRetiroRestante()) + "\n");
    cout<<"            "<<setw(56)<<( "Ha depositado en este mes: " + to_string(de.getDepositoMes()) + "\n");
    cout<<"            "<<setw(56)<<setw(56)<<"--------------------------------------------------------\n";
*/

    return (os << "\n\n\n\n            "<<setw(56)<<"--------------------------------------------------------\n"<<"            "<<setw(56)<<( "Numero de Cuenta: " + to_string(de.getNumeroCuenta()) + "\n" )<<"            "<<setw(56)<<( "Saldo: " + to_string(de.getSaldo()) + "\n" )<<"            "<<setw(56)<<"Tipo de cuenta: Debito\n"<<"            "<<setw(56)<<( activo + "\n\n" )<<"            "<<setw(56)<<( "ID: " + to_string(de.getTitular().getID()) + "\n")<<"            "<<setw(56)<<( "Nombre: " + de.getTitular().getNombre() + "\n" )<<"            "<<setw(56)<<( "Direccion: " + de.getTitular().getDireccion() + "\n" )<<"            "<<setw(56)<<( "RFC: " + de.getTitular().getRFC() + "\n" )<<"            "<<setw(56)<<( "Retiro Maximo por Dia: " + to_string(de.getRetiroMaximo()) + "\n" )<<"            "<<setw(56)<<( "Puede retirar el dia de hoy: " + to_string(de.getRetiroRestante()) + "\n")<<"            "<<setw(56)<<( "Ha depositado en este mes: " + to_string(de.getDepositoMes()) + "\n")<<"            "<<setw(56)<<setw(56)<<"--------------------------------------------------------\n");

}
