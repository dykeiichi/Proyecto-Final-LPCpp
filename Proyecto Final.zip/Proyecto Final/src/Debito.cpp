#include <iostream>
#include "Debito.h"

using namespace std;

void Debito::depositar(long double val){
    if ( val > 0){
        if (depositoMes < 25000 && depositoMes > 0){
            setSaldo(getSaldo() + val);
            depositoMes += val;
        }
        if (depositoMes > 25000){
            setSaldo(getSaldo() + val);
            setSaldo( getSaldo() - (depositoMes * 0.2) );
            depositoMes = -1;
        }
        if (depositoMes == -1){
            setSaldo(getSaldo() + (val * 0.8 ));
        }
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        cout<<"Ha ocurrido un error"<<endl;
        if(!(val > 0)){
            cout<<"Valor no valido"<<endl;
        }
    }
}

void Debito::retirar(long double val){
    if (val <= getSaldo() && val > 0){
        setSaldo(getSaldo() - val);
        retiroRestante -= val;
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        cout<<"Ha ocurrido un error"<<endl;
        if( val > getSaldo() ){
            cout<<"No dispone de suficientes fondos"<<endl;
        }
        if(!(val > 0)){
            cout<<"Valor no valido"<<endl;
        }
    }
}

void Debito::leer(Cuenta cuenta, double retiroMaximo, double retiroRestante, double depositoMes){
    this->setNumeroCuenta(cuenta.getNumeroCuenta());
    this->setTitular(cuenta.getTitular());
    this->setSaldo(cuenta.getSaldo());
    this->retiroMaximo = retiroMaximo;
    this->retiroRestante = retiroRestante;
    this->depositoMes = depositoMes;
}

bool Debito::operator<(Debito de){
    if (this->getNumeroCuenta() < de.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Debito::operator>(Debito de){
    if (this->getNumeroCuenta() > de.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Debito::operator==(Debito de){
    if (this->getNumeroCuenta() == de.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Debito::operator<=(Debito de){
    if (this->getNumeroCuenta() <= de.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Debito::operator>=(Debito de){
    if (this->getNumeroCuenta() >= de.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Debito::operator!=(Debito de){
    if (this->getNumeroCuenta() != de.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}
