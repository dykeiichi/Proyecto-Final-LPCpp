#include <iostream>
#include "Debito.h"

using namespace std;

void Debito::retirar(long double val){
    if (val < _retiro_max){
        Cuenta::retirar(val);
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        cout<<"No puede retirar mas de "<<_retiro_max<<" en un dia"<<endl;
    }
}
