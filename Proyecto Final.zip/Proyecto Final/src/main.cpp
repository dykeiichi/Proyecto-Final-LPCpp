#include <iostream>
#include "Serializacion.h"
#include "Cliente.h"

using namespace std;

int main (){
    vector<Cliente> matriz;
    Cliente * c1 = new Cliente("NOMBRE1", "DIRECCION1", "RFC1");
    matriz.push_back(*c1);
    delete c1;
    c1 = new Cliente("NOMBRE2", "DIRECCION2", "RFC2");
    matriz.push_back(*c1);
    delete c1;
    c1 = new Cliente("NOMBRE3", "DIRECCION3", "RFC3");
    matriz.push_back(*c1);
    delete c1;
    c1 = new Cliente("NOMBRE4", "DIRECCION4", "RFC4");
    matriz.push_back(*c1);

    Serializacion<Cliente> a;

    cout<<"antes de guardar"<<endl;
    a.guardar(&matriz, "Clientes.txt");
    cout<<"despues de guardar"<<endl;
    vector<Cliente> leerMatriz;

    cout<<"antes de leer"<<endl;
    a.leer(&leerMatriz, "Clientes.txt");
    cout<<"despues de leer"<<endl;

    for (unsigned int i = 0; i < leerMatriz.size() ; i++){
        leerMatriz[i].verInformacion();
    }

}
