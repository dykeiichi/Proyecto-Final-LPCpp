#include <iostream>
#include <fstream>
#include <vector>
#include "Cliente.h"
#include "Cuenta.h"
#include "Credito.h"

using namespace std;

int main (){

    //Se crea la cuenta 1
    Debito *debito1 = new Debito("NOMBRE 1", 5000, "DIRECCION 1", "RFC 1");
    debito1->depositar(5000);
    debito1->retirar(2000);
    cout<<"Saldo restante: "<<(debito1->getSaldo())<<endl;

    cout<<"-------------------------"<<endl;

    //Se crea la cuenta 2
    Debito *debito2 = new Debito("NOMBRE 2", 5000, "DIRECCION 2", "RFC 2");
    debito1->depositar(2000);
    debito1->retirar(1000);
    cout<<"Saldo restante: "<<(debito2->getSaldo())<<endl;

}
