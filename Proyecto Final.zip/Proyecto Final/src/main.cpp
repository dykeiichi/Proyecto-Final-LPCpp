#include <iostream>
#include <fstream>
#include "Cliente.h"
#include "Cuenta.h"
#include "Credito.h"
#include "Debito.h"
#include "Banco.h"

using namespace std;

int main(){

    //Hatsa 80 caracteres en una ventana de consola por default

    Banco banco = Banco();

    try{
        banco.menuInicio();
    }catch (...){

    }


}
