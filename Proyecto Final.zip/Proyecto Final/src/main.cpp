#include <iostream>
#include <fstream>
#include <vector>
#include "Cliente.h"
#include "Cuenta.h"
#include "Credito.h"

using namespace std;

void leerClientes(vector<Cliente> * v1){

    Cliente *c1 = new Cliente("NOMBRE1", "DIRECCION1", "RFC1");

    Cliente c2 = Cliente();

    ofstream archivo_out;

    archivo_out.open("Clientes.txt");

    c1->guardar(archivo_out);

    delete c1;
    c1 = new Cliente("NOMBRE2", "DIRECCION2", "RFC2");
    c1->guardar(archivo_out);

    delete c1;
    c1 = new Cliente("NOMBRE3", "DIRECCION3", "RFC3");
    c1->guardar(archivo_out);

    archivo_out.close();

    ifstream archivo_in;
    archivo_in.open("Clientes.txt");

    bool registros = c1->leer(archivo_in);

    while(registros){
        v1->push_back(*c1);
        registros = c1->leer(archivo_in);
    }

    archivo_in.close();
}

void leerCuentas(vector<Cuenta> * v1){

    Cuenta *c1 = new Cuenta(1001, 100);

    //Cuenta c2 = Cuenta();

    ofstream archivo_out;

    archivo_out.open("Cuentas.txt");

    c1->guardar(archivo_out);

    delete c1;
    c1 = new Cuenta(1002, 200);
    c1->guardar(archivo_out);

    delete c1;
    c1 = new Cuenta(1003, 300);
    c1->guardar(archivo_out);

    archivo_out.close();

    ifstream archivo_in;
    archivo_in.open("Cuentas.txt");

    bool registros;

    do{
        cout<<"1"<<endl;
        try{
            registros = c1->leer(archivo_in);
            v1->push_back(*c1);
        }catch(int i){
            switch(i){
                case 1:
                    cout<<"No existe Cliente asociado a la Cuenta"<<endl;
                    break;
                default:
                    continue;
            }
        }
    }while(registros);

    archivo_in.close();
}

void leerCreditos(vector<Credito> * v1){

    Credito *c1 = new Credito(100001);

    Credito c2 = Credito();

    ofstream archivo_out;

    archivo_out.open("Creditos.txt");

    c1->guardar(archivo_out);

    delete c1;
    c1 = new Credito(100003);
    c1->guardar(archivo_out);

    archivo_out.close();

    ifstream archivo_in;
    archivo_in.open("Creditos.txt");

    bool registros;

    do{
        try{
            registros = c1->leer(archivo_in);
            v1->push_back(*c1);
        }catch(int i){
            switch(i){
                case 1:
                    cout<<"No existe Cliente asociado a la Cuenta"<<endl;
                    break;
                default:
                    continue;
            }
        }
    }while(registros);

    archivo_in.close();
}


int main (){
    vector<Cliente> v1;
    vector<Cuenta> v2;
    vector<Credito> v3;

    cout<<"Clientes"<<endl;

    leerClientes(&v1);

    for (unsigned int i = 0; i < v1.size() ; i++){
        v1[i].verInformacion();
    }

    cout<<endl<<endl<<"Cuentas"<<endl<<endl;

    leerCuentas(&v2);

    for (unsigned int i = 0; i < v2.size() ; i++){
        v2[i].toString();
    }

    cout<<endl<<endl<<"Creditos"<<endl<<endl;
/*
    leerCreditos(&v3);

    for (unsigned int i = 0; i < v3.size() ; i++){
        v3[i].toString();
    }

    cout<<endl<<endl;
*/
}
