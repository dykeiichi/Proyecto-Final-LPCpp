#include <iostream>
#include <fstream>
#include "Cliente.h"
#include "Cuenta.h"
#include "Credito.h"
#include "Debito.h"
#include "Banco.h"

using namespace std;

int main(){

    Cliente cliente1 = Cliente("Nombre1", "Direccion1", "RFC1");

    Cuenta cuenta1 = Cuenta(2000, cliente1);

    Credito credito1 = Credito(cuenta1, 47000);

    Debito debito1 = Debito(cuenta1, 6500);

    ofstream clienteFile;
    clienteFile.open("archivos/clientes.bank");
    clienteFile<<cliente1.guardar();
    clienteFile.close();

    ofstream cuentasFile;
    cuentasFile.open("archivos/cuentas.bank");
    cuentasFile<<cuenta1.guardar();
    cuentasFile.close();

    ofstream debitoFile;
    debitoFile.open("archivos/debitos.bank");
    debitoFile<<debito1.guardar();
    debitoFile.close();

    ofstream creditoFile;
    creditoFile.open("archivos/creditos.bank");
    creditoFile<<credito1.guardar();
    creditoFile.close();

    cout<<cliente1.guardar()<<endl;
    cout<<cuenta1.guardar()<<endl;
    cout<<credito1.guardar()<<endl;
    cout<<debito1.guardar()<<endl;

    Banco banco = Banco();

    try{
        banco.menuInicio();
    }catch (...){

    }


}
