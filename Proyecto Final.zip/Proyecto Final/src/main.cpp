#include <iostream>
#include <fstream>
#include "Banco.h"

using namespace std;

int main(){

    try{
        Banco banco = Banco();
        banco.menuInicio();
    }catch (bad_alloc ba){
        cout<<"Se ha quedado sin memoria y el programa se cerrara ahora"<<endl;
    }catch(exception ex){
        cout<<"Ha ocurrido un error inesperado, reinicie la aplicacion"<<endl;
    }catch(...){
        cout<<"Algo paso :c"<<endl;
    }
}
