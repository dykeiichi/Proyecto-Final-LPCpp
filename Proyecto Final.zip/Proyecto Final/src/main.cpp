#include <iostream>
#include <fstream>
#include <vector>
#include "Cliente.h"

using namespace std;

void leerClientes(vector<Cliente> * v1){

    Cliente *c1 = new Cliente("NOMBRE1", "DIRECCION1", "RFC1");

    Cliente c2 = Cliente();

    ofstream archivo_out;

    archivo_out.open("Clientes.txt");

    c1->guardar(archivo_out);

    delete c1;
    c1 = new Cliente("NOMBRE2", "DIRECCION2", "RFC2");
    c1->guardar(archivo_out);

    delete c1;
    c1 = new Cliente("NOMBRE3", "DIRECCION3", "RFC3");
    c1->guardar(archivo_out);

    archivo_out.close();

    ifstream archivo_in;
    archivo_in.open("registros.txt");

    while(c1->leer(archivo_in)){
        v1->push_back(*c1);
    }

    archivo_in.close();
}

int main (){
    vector<Cliente> v1;

    leerClientes(&v1);

    for (unsigned int i = 0; i < v1.size() ; i++){
        v1[i].verInformacion();
    }
}
