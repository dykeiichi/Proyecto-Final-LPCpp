#include "Tiempo.h"
#include <windows.h>
#include <string>

using namespace std;

Tiempo::Tiempo(){
	SYSTEMTIME st;

	GetSystemTime(&st);

    anio = st.wYear;
    mes = st.wMonth;
    dia = st.wDay;
    hora = st.wHour;
    minutos = st.wMinute;
    segundos = st.wSecond;
    milisegundos = st.wMilliseconds;
}

Tiempo::Tiempo(int anio, int mes, int dia, int hora, int minutos, int segundos, int milisegundos){
    this->anio = anio;
    this->mes = mes;
    this->dia = dia;
    this->hora = hora;
    this->minutos = minutos;
    this->segundos = segundos;
    this->milisegundos = milisegundos;
}

int Tiempo::getAnio(){
    return anio;
}

int Tiempo::getMes(){
    return mes;
}

int Tiempo::getDia(){
    return dia;
}

int Tiempo::getHora(){
    return hora;
}

int Tiempo::getMinutos(){
    return minutos;
}

int Tiempo::getSegundos(){
    return segundos;
}

int Tiempo::getMilisegundos(){
    return milisegundos;
}

Tiempo Tiempo::operator+(Tiempo val){

    bool decision = true;
    int anioTemp = anio + val.getAnio();
    int mesTemp = mes + val.getMes();
    int diaTemp = dia + val.getDia();
    int horaTemp = hora + val.getHora();
    int minutosTemp = minutos + val.getMinutos();
    int segundosTemp = segundos + val.getSegundos();
    int milisegundosTemp = milisegundos + val.getMilisegundos();


    if (milisegundosTemp > 999){
        milisegundosTemp -= 1000;
        segundosTemp++;
    }

    if (segundosTemp > 59){
        segundosTemp -= 60;
        minutosTemp++;
    }

    if (minutosTemp > 59){
        minutosTemp -= 60;
        horaTemp++;
    }

    if (horaTemp > 23){
        horaTemp -= 24;
        diaTemp++;
    }

    while (mesTemp > 12){
        mesTemp -= 12;
        anioTemp++;
    }

    while(decision){
        decision = false;
        switch(mes){
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
                if (diaTemp > 31){
                    diaTemp -= 31;
                    mesTemp++;
                    decision = true;
                }
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                if (diaTemp > 30){
                    diaTemp -= 30;
                    mesTemp++;
                    decision = true;
                }
                break;
            case 2:
                if (anioTemp % 4 == 0){
                    if (diaTemp > 29){
                        diaTemp -= 29;
                        mesTemp++;
                        decision = true;
                    }
                }else{
                    if (diaTemp > 28){
                        diaTemp -= 28;
                        mesTemp++;
                        decision = true;
                    }
                }
                break;
            case 12:
                    if (diaTemp > 31){
                        diaTemp -= 31;
                        mesTemp = 1;
                        anioTemp++;
                        decision = true;
                    }
                    break;
            default:
                break;
        }
    }

    return Tiempo(anioTemp, mesTemp, diaTemp, horaTemp, minutosTemp, segundosTemp, milisegundosTemp);

}

Tiempo Tiempo::operator-(Tiempo val){

    bool decision = true;
    int anioTemp = anio - val.getAnio();
    int mesTemp = mes - val.getMes();
    int diaTemp = dia - val.getDia();
    int horaTemp = hora - val.getHora();
    int minutosTemp = minutos - val.getMinutos();
    int segundosTemp = segundos - val.getSegundos();
    int milisegundosTemp = milisegundos - val.getMilisegundos();


    if (milisegundosTemp < 0){
        milisegundosTemp += 1000;
        segundosTemp--;
    }

    if (segundosTemp < 0){
        segundosTemp += 60;
        minutosTemp--;
    }

    if (minutosTemp < 0){
        minutosTemp += 60;
        horaTemp--;
    }

    if (horaTemp < 0){
        horaTemp += 24;
        diaTemp--;
    }

    while (mesTemp < 1){
        mesTemp += 12;
        anioTemp--;
    }

    while(decision){
        decision = false;
        switch(mes){
            case 2:
            case 4:
            case 6:
            case 9:
            case 11:
                if (diaTemp < 1){
                    diaTemp += 31;
                    mesTemp--;
                    decision = true;
                }
                break;
            case 5:
            case 7:
            case 10:
            case 12:
                if (diaTemp < 1){
                    diaTemp += 30;
                    mesTemp--;
                    decision = true;
                }
                break;
            case 3:
                if (anioTemp % 4 == 0){
                    if (diaTemp < 1){
                        diaTemp += 29;
                        mesTemp--;
                        decision = true;
                    }
                }else{
                    if (diaTemp < 1){
                        diaTemp += 28;
                        mesTemp--;
                        decision = true;
                    }
                }
                break;
            case 1:
                    if (diaTemp < 1){
                        diaTemp += 31;
                        mesTemp = 12;
                        anioTemp--;
                        decision = true;
                    }
                    break;
            default:
                break;
        }
    }

    return Tiempo(anioTemp, mesTemp, diaTemp, horaTemp, minutosTemp, segundosTemp, milisegundosTemp);
}

Tiempo::operator long long(){

    // para mes se multiplico el numero anterior por 30.4375 que es el resultado de sacar el promedio de dias que tiene un mes en cuatro a�os para contar el dia bisciesto
    return ((long long)anio * 31557600000) + ((long long)mes * 2629800000) + ((long long)dia * 86400000) + ((long long)hora * 3600000) + ((long long)minutos * 60000) + ((long long)segundos * 1000) + ((long long)milisegundos);
}

ostream& operator<<(ostream& os,  Tiempo t){
    return (os << "[" << t.getAnio() << "/" << t.getMes() << "/" << t.getDia() << " - " << t.getHora() << ":" << t.getMinutos() << ":" << t.getSegundos() << ":" << t.getMilisegundos() << "]");
}

Tiempo Tiempo::operator++(){
    *this = *this + Tiempo(0,0,0,0,0,0,1);
    return *this;
}

Tiempo Tiempo::operator++(int){
    Tiempo temp = *this;
    *this = *this + Tiempo(0,0,0,0,0,0,1);
    return temp;
}

Tiempo Tiempo::operator--(){
    *this = *this - Tiempo(0,0,0,0,0,0,1);
    return *this;
}

Tiempo Tiempo::operator--(int){
    Tiempo temp = *this;
    *this = *this - Tiempo(0,0,0,0,0,0,1);
    return temp;
}
