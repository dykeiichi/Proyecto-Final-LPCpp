#include <iostream>
#include "Cuenta.h"
#include "Cliente.h"

using namespace std;

long Cuenta::numCuenta = 10000;

void Cuenta::setNumCuenta(){
    numCuenta++;
}

long Cuenta::getNumCuenta(){
    return numCuenta;
}

void Cuenta::setNumeroCuenta(){
    numeroCuenta = numCuenta;
}

void Cuenta::setNumeroCuenta(long val){
    numeroCuenta = val;
}

long Cuenta::getNumeroCuenta(){
    return numeroCuenta;
}

Cliente Cuenta::getTitular(){
    return titular;
}

void Cuenta::setSaldo(long double saldoIn){
    saldo = saldoIn;
}

long double Cuenta::getSaldo(){
    return saldo;
}

void Cuenta::toString(){
    cout<<"Numero de Cuenta: "<<numCuenta<<endl;
    cout<<"Saldo: "<<saldo<<endl;
    titular.verInformacion();
}

void Cuenta::saldoToString(){
    cout<<"Saldo: "<<saldo<<endl;
}

void Cuenta::leer(long numeroCuenta, Cliente titular, long double saldo){
    this->numeroCuenta = numeroCuenta;
    this->titular = titular;
    this->saldo = saldo;
}
