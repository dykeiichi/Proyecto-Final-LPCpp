#include <iostream>
#include <fstream>
#include "Cuenta.h"
#include "Cliente.h"

using namespace std;

long Cuenta::val = 100001;

void Cuenta::setVal(){
    val++;
}

long Cuenta::getVal(){
    return val;
}

long Cuenta::getNumCuenta(){
    return numCuenta;
}

void Cuenta::setTitular(long id){
    titular.leer(id);
}

Cliente Cuenta::getTitular(){
    return titular;
}

void Cuenta::setSaldo(long double saldoIn){
    saldo = saldoIn;
}

long double Cuenta::getSaldo(){
    return saldo;
}

void Cuenta::retirar(long double retiro){
    if (retiro > 0){
        if(retiro > saldo){
            cout<<"No cuenta con suficientes fondos"<<endl;
        }else{
            saldo -= retiro;
            cout<<"La transaccion ha sido realizada exitosamente"<<endl;
        }
    }else{
        cout<<"Valor no valido"<<endl;
    }
}

void Cuenta::depositar(long double deposito){
    if (deposito > 0){
        saldo += deposito;
        cout<<"La transaccion ha sido realizada exitosamente"<<endl;
    }else{
        cout<<"Valor no valido"<<endl;
    }
}

void Cuenta::toString(){
    cout<<"-------------------------------"<<endl;
    cout<<"Numero de Cuenta: "<<numCuenta<<endl;
    cout<<"Saldo: "<<saldo<<endl;
    titular.verInformacion();
}

void Cuenta::saldoToString(){
    cout<<"Saldo: "<<saldo<<endl;
}

void Cuenta::guardar(ofstream& salida){
    salida<<numCuenta<<","<<saldo<<","<<titular.getID()<<endl;
}

bool Cuenta::leer(ifstream& archivo){
    const int SIZE = 500;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, ',');
    if (!archivo.good()){
        return false;
    }else{
        numCuenta = atol(buffer);

        archivo.getline(buffer, SIZE, ',');
        saldo = strtold(buffer, nullptr);

        archivo.getline(buffer, SIZE, '\n');
        titular.leer(atol(buffer));

        return true;
    }
}

bool Cuenta::leer(ifstream& archivo, long cuenta){
    const int SIZE = 500;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, ',');
    if (!archivo.good()){
        return false;
    }else{
        do{
            numCuenta = atol(buffer);

            archivo.getline(buffer, SIZE, ',');
            saldo = strtold(buffer, nullptr);

            archivo.getline(buffer, SIZE, '\n');
            titular.leer(atol(buffer));

            if (numCuenta == 0){
                throw 1;
            }

        }while(cuenta != numCuenta);
        return true;
    }
}
