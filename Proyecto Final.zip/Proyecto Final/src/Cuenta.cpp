#include <iostream>
#include <iomanip>
#include "Cuenta.h"
#include "Cliente.h"

using namespace std;

long Cuenta::numCuenta = 10000;

Cuenta::Cuenta(long val1, Cliente val2, long double val3, bool val4){
    this->numeroCuenta = val1;
    this->titular = val2;
    this->saldo = val3;
    this->tipo = val4;
}

Cuenta::Cuenta(){

}

Cuenta::Cuenta(long double saldo, Cliente cliente, bool tipo){
    setNumCuenta();
    setNumeroCuenta();
    setSaldo(saldo);
    //Le dice a cliente que lea sus datos del archivo segun su id
    titular.setThis(cliente);
    this->tipo = tipo;
}

void Cuenta::setNumCuenta(){
    numCuenta++;
}

void Cuenta::setNumCuenta(long val1){
    numCuenta = val1;
}

long Cuenta::getNumCuenta(){
    return numCuenta;
}

void Cuenta::setTipo(bool val1){
    this->tipo = val1;
}

bool Cuenta::getTipo(){
    return tipo;
}

void Cuenta::setActivo(bool val1){
    this->activo = val1;
}

bool Cuenta::getActivo(){
    return activo;
}

void Cuenta::setNumeroCuenta(){
    numeroCuenta = numCuenta;
}

void Cuenta::setNumeroCuenta(long val){
    numeroCuenta = val;
}

long Cuenta::getNumeroCuenta(){
    return numeroCuenta;
}

Cliente Cuenta::getTitular(){
    return titular;
}

void Cuenta::setTitular(Cliente cliente){
    titular.setThis(cliente);
}

void Cuenta::setSaldo(long double saldoIn){
    saldo = saldoIn;
}

long double Cuenta::getSaldo(){
    return saldo;
}

void Cuenta::setDirecion(string val){
    titular.setDireccion(val);
}

void Cuenta::toString(){
    cout<<"-------------------------------------------------------------------"<<endl;
    cout<<"Numero de Cuenta: "<<numeroCuenta<<endl;
    cout<<"Saldo: "<<saldo<<endl;
    if (tipo == true){
        cout<<"Tipo de cuenta: Debito"<<endl;
    }else{
        cout<<"Tipo de cuenta: Credito"<<endl;
    }
    if (activo == true){
        cout<<"Se encuentra: Activa"<<endl;
    }else{
        cout<<"Se encuentra: Inactiva"<<endl;
    }
    titular.verInformacion();
    cout<<"-------------------------------------------------------------------"<<endl;
}

void Cuenta::saldoToString(){
    cout<<"Saldo: "<<saldo<<endl;
}

string Cuenta::guardar(){
    return "" + to_string(getNumeroCuenta()) + '@' + to_string(titular.getID()) + '@' + to_string(saldo) + '@' + to_string((int)tipo) + '@' + to_string((int)activo) +  "\n";
}

void Cuenta::leer(long numeroCuenta, Cliente titular, long double saldo, bool tipo, bool activo){
    this->numeroCuenta = numeroCuenta;
    this->titular = titular;
    this->saldo = saldo;
    this->tipo = tipo;
    this->activo = activo;
}

bool Cuenta::operator<(Cuenta cu){
    if (this->numeroCuenta < cu.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Cuenta::operator>(Cuenta cu){
    if (this->numeroCuenta > cu.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Cuenta::operator==(Cuenta cu){
    if (this->numeroCuenta == cu.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Cuenta::operator<=(Cuenta cu){
    if (this->numeroCuenta <= cu.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Cuenta::operator>=(Cuenta cu){
    if (this->numeroCuenta >= cu.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

bool Cuenta::operator!=(Cuenta cu){
    if (this->numeroCuenta != cu.getNumeroCuenta()){
        return true;
    }else{
        return false;
    }
}

ostream& operator<<(ostream& os, Cuenta cu){
    return (os << setw(10) << cu.getNumeroCuenta()  << " | " << setw(55) << cu.getTitular().getNombre() << " | " << setw(7)<< (cu.getTipo() ? "Debito" : "Credito"));
}
