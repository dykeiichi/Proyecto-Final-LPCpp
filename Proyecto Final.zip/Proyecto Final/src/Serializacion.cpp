#include "Serializacion.h"

Serializacion::Serializacion()
{
    //ctor
}
