#include "Banco.h"
#include "Ordenar.h"
#include <iomanip>
#include <conio.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <windows.h>

using namespace std;

Banco::Banco(){

    system("cls");
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\nLeyendo informacion de los clientes...";
    ifstream clientesFile;
    clientesFile.open("archivos/clientes.bank");
    Cliente cliente = Cliente();
    while(leerClientes(clientesFile, cliente)){
        clientes.push_back(cliente);
    }
    clientesFile.close();

    system("cls");
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\nLeyendo informacion de las cuentas...";
    ifstream cuentasFile;
    cuentasFile.open("archivos/cuentas.bank");
    Cuenta cuenta = Cuenta();
    while(leerCuentas(cuentasFile, cuenta, clientes)){
        cuentas.push_back(cuenta);
    }
    cuentasFile.close();

    system("cls");
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\nLeyendo informacion de las cuentas de debito...";
    ifstream debitoFile;
    debitoFile.open("archivos/debitos.bank");
    Debito debito = Debito();
    while(leerDebitos(debitoFile, debito, cuentas)){
        debitos.push_back(debito);
    }
    debitoFile.close();

    system("cls");
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\nLeyendo informacion de las cuentas de credito...";
    ifstream creditoFile;
    creditoFile.open("archivos/debitos.bank");
    Credito credito = Credito();
    while(leerCreditos(creditoFile, credito, cuentas)){
        creditos.push_back(credito);
    }
    creditoFile.close();

    system("cls");
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\nOrdenando informacion (clientes)...";
    Ordenar<Cliente> cl;
    cl.ordenar(clientes);
    delete &cl;

    system("cls");
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\nOrdenando informacion (cuentas)...";
    Ordenar<Cuenta> cu;
    cu.ordenar(cuentas);
    delete &cu;

    system("cls");
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\nOrdenando informacion (creditos)...";
    Ordenar<Credito> cr;
    cr.ordenar(creditos);
    delete &cr;

    system("cls");
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\nOrdenando informacion (debitos)...";
    Ordenar<Debito> de;
    de.ordenar(debitos);
    delete &de;

    system("cls");

    if (clientes.size() > 0){
        Cliente *cltmp = new Cliente();
        cltmp->setVal(clientes[clientes.size() -1].getID());
        delete cltmp;
    }

    if (cuentas.size() > 0){
        Cuenta *cutmp = new Cuenta();
        cutmp->setNumCuenta(cuentas[cuentas.size() - 1].getNumeroCuenta());
        delete cutmp;
    }
}

Banco::~Banco(){

    ofstream archivo;
    archivo.open("archivos/clientes.bank");
    for (unsigned int i = 0; i < clientes.size() ; i++){
        archivo<<clientes[i].guardar();
    }
    archivo.close();

    archivo.open("archivos/cuentas.bank");
    for (unsigned int i = 0; i < cuentas.size() ; i++){
        archivo<<cuentas[i].guardar();
    }
    archivo.close();

    archivo.open("archivos/creditos.bank");
    for (unsigned int i = 0; i < creditos.size() ; i++){
        archivo<<creditos[i].guardar();
    }
    archivo.close();

    archivo.open("archivos/debitos.bank");
    for (unsigned int i = 0; i < debitos.size() ; i++){
        archivo<<debitos[i].guardar();
    }
    archivo.close();
}

void Banco::menuInicio(){
    int i = 0;
    char tecla = '\n';
    do{
        cout<<"\n\n\n\n\n\n\n";
        if(i == 0){
            cout<<"                          Ver Lista De Cuentas   (*)                          "<<endl;
        }else{
            cout<<"                          Ver Lista De Cuentas   ( )                          "<<endl;
        }

        if(i == 1){
            cout<<"                          Agregar Una Cuenta     (*)                          "<<endl;
        }else{
            cout<<"                          Agregar Una Cuenta     ( )                          "<<endl;
        }

        if(i == 2){
            cout<<"                          Modificar Cuenta       (*)                          "<<endl;
        }else{
            cout<<"                          Modificar Cuenta       ( )                          "<<endl;
        }

        if(i == 3){
            cout<<"                          Baja De Cuentas        (*)                          "<<endl;
        }else{
            cout<<"                          Baja De Cuentas        ( )                          "<<endl;
        }

        if(i == 4){
            cout<<"                          Depositar              (*)                          "<<endl;
        }else{
            cout<<"                          Depositar              ( )                          "<<endl;
        }

        if(i == 5){
            cout<<"                          Retirar                (*)                          "<<endl;
        }else{
            cout<<"                          Retirar                ( )                          "<<endl;
        }

        if(i == 6){
            cout<<"                          Consultar              (*)                          "<<endl;
        }else{
            cout<<"                          Consultar              ( )                          "<<endl;
        }

        if(i == 7){
            cout<<"                          Salir                  (*)                          "<<endl;
        }else{
            cout<<"                          Salir                  ( )                          "<<endl;
        }


        tecla = getch();
        system("cls");
        switch(tecla){
            case 13:
                switch(i){
                    case 0:
                        verListaDeCuentas();
                        break;
                    case 1:
                        agregarUnaCuenta();
                        break;
                    case 2:
                        modificarCuenta();
                        break;
                    case 3:
                        bajaDeCuentas();
                        break;
                    case 4:
                        depositar();
                        break;
                    case 5:
                        retirar();
                        break;
                    case 6:
                        consultar();
                        break;
                    case 7:
                        salir();
                        break;
                    default:
                        continue;
                }
                break;
            case 72:    //Arriba
                if(i>0){
                    i--;
                }else{
                    i = 7;
                }
                break;
            case 80:    //Abajo
                if(i<7){
                    i++;
                }else{
                    i = 0;
                }
                break;
            default:
                cout<<(int)tecla<<endl;
                continue;
        }
    }while(true);

}

void Banco::verListaDeCuentas(){
    char tecla = '\n';
    unsigned int aux1 = 0;
    unsigned int aux2 = 12;

    do{
        cout<<"Salir(q)        -        Av. Pag.(Espacio)        -        Av. Linea(Flecha)"<<endl<<endl;

        for (unsigned int i = aux1; i < cuentas.size() && i < aux2; i++){
            cout<<cuentas[i]<<endl;
        }


        tecla = getch();
        system("cls");
        switch(tecla){
            case 32:   // 'Espacio'
                if ((cuentas.size() - 12) >= (aux1 + 12) ){
                    aux1 += 12;
                    aux2 = aux1 + 12;
                }else{
                    aux1 = cuentas.size() - 12;
                    aux2 = aux1 + 12;
                }
                break;
            case 72:    //arriba
                if (aux1 > 0){
                    aux1 --;
                    aux2 = aux1 + 12;
                }
                break;
            case 80:    //abajo
                if ((cuentas.size() - 12) >= (aux1 + 1)){
                    aux1++;
                    aux2 = aux1 + 12;
                }
                break;
            default:
                continue;
        }
    }while(tecla != 'q');
}

void Banco::agregarUnaCuenta(){
    char tecla = '\n';
    int i = 0;
    do{
        cout<<"\n\n\n\n\n\n\n";
        cout<<"                      Agregar cuenta a Cliente existente?                     \n\n"<<endl;
        if(i == 0){
            cout<<"               Existente (*)                          Nuevo ( )               "<<endl;
        }else{
            cout<<"               Existente ( )                          Nuevo (*)               "<<endl;
        }

    tecla = getch();
        system("cls");
        switch(tecla){
            case 75:    //izquierda
            case 77:    //derecha
                if (i == 0){
                    i = 1;
                }else{
                    i = 0;
                }
                break;
            default:
                continue;
        }
    }while(tecla != 'q' && tecla != 13);
    //agregar codigp para creacion de cliente o asignacion en su defecto
    if (tecla != 'q'){
        if (i == 0){
            agregarCuentaExistente(tecla, i);
        }else{
            agregarCuentaNuevo(tecla, i);
            //agregar codigo de cliente no existente
        }
    }

}

void Banco::modificarCuenta(){
    long num_Cuenta = 0;
    char tecla = '\n';
    unsigned int posicion = 0;
    do{
        cout<<"\n\n\n\n\n\n\n";
        cout<<"                          Escriba su  Numero de Cuenta                        \n\n"<<endl;
        cout<<"                                     "<<setw(6)<<num_Cuenta<<"                                     "<<endl;

        tecla = getch();
        switch (tecla){
            case 8:
                num_Cuenta /= 10;
                break;
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
                num_Cuenta = (num_Cuenta * 10) + (tecla - 48);
                break;
            default:
                break;
        }
        system("cls");
        if (tecla == 'q'){
            break;
        }
    }while(tecla != 13);

    Cuenta cu = Cuenta();
    for (posicion = 0; posicion < cuentas.size(); posicion++){
        if (cuentas[posicion].getNumeroCuenta() == num_Cuenta){
            cu = cuentas[posicion];
        }
    }
    cu.toString();

    int i = 0;
    do{
        cout<<"\n\n\n\n\n\n\n";
        if(i == 0){
            cout<<"                       Modificar Direccion          (*)                       "<<endl;
        }else{
            cout<<"                       Modificar Direccion          ( )                       "<<endl;
        }

        if(i == 1){
            cout<<"                       Modificar limite de credito  (*)                       "<<endl;
        }else{
            cout<<"                       Modificar limite de credito  ( )                       "<<endl;
        }

        if(i == 2){
            cout<<"                       Modificar limite de retiro   (*)                          "<<endl;
        }else{
            cout<<"                       Modificar limite de retiro   ( )                          "<<endl;
        }

        tecla = getch();
        system("cls");
        switch(tecla){
            case 13:
                switch(i){
                    case 0:{
                        string direccion = "";
                        recibirDireccion(tecla, direccion);
                        cu.getTitular().setDireccion(direccion);
                        cuentas[posicion] = cu;
                        break;
                    }
                    case 1:
                        agregarUnaCuenta();
                        break;
                    case 2:
                        modificarCuenta();
                        break;
                    default:
                        continue;
                }
                break;
            case 72:    //Arriba
                if(i>0){
                    i--;
                }else{
                    i = 2;
                }
                break;
            case 80:    //Abajo
                if(i<2){
                    i++;
                }else{
                    i = 0;
                }
                break;
            default:
                cout<<(int)tecla<<endl;
                continue;
        }
    }while(tecla != 'q');

}

void Banco::bajaDeCuentas(){
    cout<<"bajaDeCuentas()"<<endl;
}

void Banco::depositar(){
    cout<<"depositar()"<<endl;
}

void Banco::retirar(){
    cout<<"retirar()"<<endl;
}

void Banco::consultar(){
    char tecla = '\n';
    long num_cuenta = 0;
    do{
        recibirNumeroCuenta(tecla, num_cuenta);
        for (unsigned int i = 0; i < cuentas.size() ; i++){
            if (cuentas[i].getNumeroCuenta() == num_cuenta){
                cuentas[i].toString();
                break;
            }else{
                continue;
            }
        }
        cout<<"\nOprima cualquier tecla para consultar otra cuenta o 'q' para salir"<<endl;
        tecla = getch();
        system("cls");
        num_cuenta = 0;
    }while(tecla != 'q');
}

void Banco::salir(){
    this->~Banco();
    exit(0);
}

bool Banco::leerClientes(ifstream& archivo, Cliente& cliente){
    const int SIZE = 1000;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, '@');
    if (!archivo.good()){
        return false;
    }else{
        long ID = stol(buffer);

        archivo.getline(buffer, SIZE, '@');
        string nombre = buffer;

        archivo.getline(buffer, SIZE, '@');
        string direccion = buffer;

        archivo.getline(buffer, SIZE, '\n');
        string RFC = buffer;

        cliente.leer(ID, nombre, direccion, RFC);

        return true;
    }
}

bool Banco::leerCuentas(ifstream& archivo, Cuenta& cuenta, vector<Cliente>& vectorCliente){
    const int SIZE = 1000;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, '@');
    if (!archivo.good()){
        return false;
    }else{
        long numeroCuenta = stol(buffer);

        archivo.getline(buffer, SIZE, '@');
        long ID_titular = stol(buffer);

        archivo.getline(buffer, SIZE, '@');
        long double saldo = stold(buffer);

        archivo.getline(buffer, SIZE, '@');
        int tipo = stoi(buffer);

        archivo.getline(buffer, SIZE, '\n');
        int activo = stoi(buffer);

        unsigned int i = 0;
        for (; i < vectorCliente.size(); i++){
            if (vectorCliente[i].getID() == ID_titular){
                break;
            }else{
                continue;
            }
        }

        cuenta.leer(numeroCuenta, vectorCliente[i], saldo, tipo, activo);
        return true;
    }
}

bool Banco::leerDebitos(ifstream& archivo, Debito& debito, vector<Cuenta>& vectorCuenta){
    const int SIZE = 1000;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, '@');
    if (!archivo.good()){
        return false;
    }else{
        long numeroCuenta = stol(buffer);

        archivo.getline(buffer, SIZE, '@');
        long maxRet = stol(buffer);

        archivo.getline(buffer, SIZE, '@');
        long resRet = stol(buffer);

        archivo.getline(buffer, SIZE, '\n');
        long depositoMes = stol(buffer);

        unsigned int i = 0;
        for (; i < vectorCuenta.size(); i++){
            if (vectorCuenta[i].getNumeroCuenta() == numeroCuenta){
                break;
            }else{
                continue;
            }
        }
        if ( i < vectorCuenta.size()){
            debito.leer(vectorCuenta[i], maxRet, resRet, depositoMes);
        }

        return true;
    }
}

bool Banco::leerCreditos(ifstream& archivo, Credito& credito, vector<Cuenta>& vectorCuenta){
    const int SIZE = 1000;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, '@');
    if (!archivo.good()){
        return false;
    }else{
        long numeroCuenta = stol(buffer);

        archivo.getline(buffer, SIZE, '\n');
        long double creditoDis = stold(buffer);

        unsigned int i = 0;
        for (; i < vectorCuenta.size(); i++){
            if (vectorCuenta[i].getNumeroCuenta() == numeroCuenta){
                break;
            }else{
                continue;
            }
        }

        credito.leer(vectorCuenta[i], creditoDis);

        return true;
    }
}

void Banco::agregarCuentaExistente(char & tecla, int & i){
    long id_cliente = 0;
    recibirIDCliente(tecla, i, id_cliente);
    tipoCuenta(tecla, i);
    escribirNuevasCuentas(tecla, i, id_cliente);
}

void Banco::agregarCuentaNuevo(char & tecla, int & i){
    long id_cliente = 0;
    string nombre = "";
    string direccion = "";
    string rfc = "";
    recibirNombre(tecla, i, nombre);
    recibirDireccion(tecla, direccion);
    recibirRFC(tecla, i, rfc);
    tipoCuenta(tecla, i);

    Cliente cl = Cliente(nombre, direccion, rfc);
    clientes.push_back(cl);
    fstream archivo;
    archivo.open("archivos/clientes.bank", ios::app);
    archivo<<cl.guardar();
    archivo.close();
    id_cliente = cl.getID();
    delete &cl;

    escribirNuevasCuentas(tecla, i, id_cliente);

}

void Banco::recibirDireccion(char &tecla, string &direccion){
    do{
        cout<<"\n\n\n\n\n\n\n";
        cout<<"                              Escriba su direccion                            \n\n"<<endl;
        cout<<" "<<setw(78)<<direccion<<" "<<endl;

        tecla = getch();
        switch (tecla){
            case 8:
                if (direccion.length() > 0){
                    direccion.erase(direccion.length() -1);
                }
                break;
            case 32:
            case 35:
            case 44:
            case 46:
            case 47:
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 58:
            case 59:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 71:
            case 72:
            case 73:
            case 74:
            case 75:
            case 76:
            case 77:
            case 78:
            case 79:
            case 80:
            case 81:
            case 82:
            case 83:
            case 84:
            case 85:
            case 86:
            case 87:
            case 88:
            case 89:
            case 90:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
            case 107:
            case 108:
            case 109:
            case 110:
            case 111:
            case 112:
            case 113:
            case 114:
            case 115:
            case 116:
            case 117:
            case 118:
            case 119:
            case 120:
            case 121:
            case 122:
                direccion = direccion + tecla;
                break;
            default:
                break;
        }
        system("cls");
    }while(tecla != 13);
}

void Banco::tipoCuenta(char& tecla, int & i){
    do{
        cout<<"\n\n\n\n\n\n\n";
        cout<<"                                Credito o Debito                              \n\n"<<endl;
        if(i == 0){
            cout<<"                 Credito (*)                         Debito ( )               "<<endl;
        }else{
            cout<<"                 Credito ( )                         Debito (*)               "<<endl;
        }

    tecla = getch();
        system("cls");
        switch(tecla){
            case 75:    //izquierda
            case 77:    //derecha
                if (i == 0){
                    i = 1;
                }else{
                    i = 0;
                }
                break;
            default:
                continue;
        }
    }while(tecla != 13);
}

void Banco::recibirIDCliente(char& tecla, int& i, long & id_cliente){
    do{
        cout<<"\n\n\n\n\n\n\n";
        cout<<"                            Escriba su id de cliente                          \n\n"<<endl;
        cout<<"                                      "<<setw(4)<<id_cliente<<"                                      "<<endl;

        tecla = getch();
        switch (tecla){
            case 8:
                id_cliente /= 10;
                break;
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
                id_cliente = (id_cliente * 10) + (tecla - 48);
                break;
            default:
                break;
        }
        system("cls");
    }while(tecla != 13);
}

void Banco::recibirNumeroCuenta(char& tecla, long & num_cuenta){
    do{
        cout<<"\n\n\n\n\n\n\n";
        cout<<"                           Escriba su numero de cuenta                        \n\n"<<endl;
        cout<<"                                     "<<setw(6)<<num_cuenta<<"                                     "<<endl;

        tecla = getch();
        switch (tecla){
            case 8:
                num_cuenta /= 10;
                break;
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
                num_cuenta = (num_cuenta * 10) + (tecla - 48);
                break;
            default:
                break;
        }
        system("cls");
    }while(tecla != 13);
}

void Banco::recibirNombre(char& tecla, int& i, string& nombre){
    do{
        cout<<"\n\n\n\n\n\n\n";
        cout<<"                           Escriba su nombre Completo                         \n\n"<<endl;
        cout<<" "<<setw(78)<<nombre<<" "<<endl;

        tecla = getch();
        switch (tecla){
            case 8:
                if (nombre.length() > 0){
                    nombre.erase(nombre.length() -1);
                }
                break;
            case 32:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 71:
            case 72:
            case 73:
            case 74:
            case 75:
            case 76:
            case 77:
            case 78:
            case 79:
            case 80:
            case 81:
            case 82:
            case 83:
            case 84:
            case 85:
            case 86:
            case 87:
            case 88:
            case 89:
            case 90:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
            case 107:
            case 108:
            case 109:
            case 110:
            case 111:
            case 112:
            case 113:
            case 114:
            case 115:
            case 116:
            case 117:
            case 118:
            case 119:
            case 120:
            case 121:
            case 122:
                nombre = nombre + tecla;
                break;
            default:
                break;
        }
        system("cls");
    }while(tecla != 13);
}

void Banco::recibirRFC(char& tecla, int& i, string& rfc){
   do{
        cout<<"\n\n\n\n\n\n\n";
        cout<<"                                 Escriba su RFC                               \n\n"<<endl;
        cout<<" "<<setw(78)<<rfc<<" "<<endl;

        tecla = getch();
        switch (tecla){
            case 8:
                if (rfc.length() > 0){
                    rfc.erase(rfc.length() -1);
                }
                break;
            case 32:
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 71:
            case 72:
            case 73:
            case 74:
            case 75:
            case 76:
            case 77:
            case 78:
            case 79:
            case 80:
            case 81:
            case 82:
            case 83:
            case 84:
            case 85:
            case 86:
            case 87:
            case 88:
            case 89:
            case 90:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
            case 107:
            case 108:
            case 109:
            case 110:
            case 111:
            case 112:
            case 113:
            case 114:
            case 115:
            case 116:
            case 117:
            case 118:
            case 119:
            case 120:
            case 121:
            case 122:
                rfc = rfc + tecla;
                break;
            default:
                break;
        }
        system("cls");
    }while(tecla != 13);
}

void Banco::escribirNuevasCuentas(char& tecla, int& i, long& id_cliente){
    unsigned int j;
    for (j = 0; j < clientes.size(); j++){
        if (clientes[j].getID() == id_cliente){
            break;
        }else{
            continue;
        }
    }
    if (j < clientes.size()){
        Cuenta cu = Cuenta(0, clientes[j], i);
        cuentas.push_back(cu);
        fstream archivo;
        archivo.open("archivos/cuentas.bank", ios::app);
        archivo<<cu.guardar();
        archivo.close();

        if (i == 0){
            Credito cr = Credito(cu);
            creditos.push_back(cr);
            fstream archivo;
            archivo.open("archivos/creditos.bank", ios::app);
            archivo<<cr.guardar();
            archivo.close();
        }else{
            Debito db = Debito(cu);
            debitos.push_back(db);
            fstream archivo;
            archivo.open("archivos/debitos.bank", ios::app);
            archivo<<db.guardar();
            archivo.close();
        }
        //codigo escribir cuentas en archivo
    }else{
        cout<<"Ha ocurrido un error"<<endl;
    }
}
