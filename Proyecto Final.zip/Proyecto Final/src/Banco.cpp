#include "Banco.h"
#include <conio.h>
#include <vector>
#include <iostream>
#include <fstream>

using namespace std;

Banco::Banco(){
    ifstream clientesFile;
    clientesFile.open("archivos/clientes.bank");
    Cliente cliente = Cliente();
    while(leerClientes(clientesFile, cliente)){
        clientes.push_back(cliente);
    }
    clientesFile.close();

    ifstream cuentasFile;
    cuentasFile.open("archivos/cuentas.bank");
    Cuenta cuenta = Cuenta();
    while(leerCuentas(cuentasFile, cuenta, clientes)){
        cuentas.push_back(cuenta);
    }
    cuentasFile.close();

    ifstream debitoFile;
    debitoFile.open("archivos/debitos.bank");
    Debito debito = Debito();
    while(leerDebitos(debitoFile, debito, cuentas)){
        debitos.push_back(debito);
    }
    debitoFile.close();

    ifstream creditoFile;
    creditoFile.open("archivos/debitos.bank");
    Credito credito = Credito();
    while(leerCreditos(creditoFile, credito, cuentas)){
        creditos.push_back(credito);
    }
    creditoFile.close();
}

void Banco::menuInicio(){
    int i = 0;
    char tecla = ' ';
    do{
        cout<<"                                     "<<endl;
        if(i == 0){
            cout<<"      Ver Lista De Cuentas   (*)     "<<endl;
        }else{
            cout<<"      Ver Lista De Cuentas   ( )     "<<endl;
        }

        if(i == 1){
            cout<<"      Agregar Una Cuenta     (*)     "<<endl;
        }else{
            cout<<"      Agregar Una Cuenta     ( )     "<<endl;
        }

        if(i == 2){
            cout<<"      Modificar Cuenta       (*)     "<<endl;
        }else{
            cout<<"      Modificar Cuenta       ( )     "<<endl;
        }

        if(i == 3){
            cout<<"      Baja De Cuentas        (*)     "<<endl;
        }else{
            cout<<"      Baja De Cuentas        ( )     "<<endl;
        }

        if(i == 4){
            cout<<"      Depositar              (*)     "<<endl;
        }else{
            cout<<"      Depositar              ( )     "<<endl;
        }

        if(i == 5){
            cout<<"      Retirar                (*)     "<<endl;
        }else{
            cout<<"      Retirar                ( )     "<<endl;
        }

        if(i == 6){
            cout<<"      Consultar              (*)     "<<endl;
        }else{
            cout<<"      Consultar              ( )     "<<endl;
        }

        if(i == 7){
            cout<<"      Salir                  (*)     "<<endl;
        }else{
            cout<<"      Salir                  ( )     "<<endl;
        }


        tecla = getch();
        system("cls");
        switch(tecla){
            case 13:
                switch(i){
                    case 0:
                        verListaDeCuentas();
                        break;
                    case 1:
                        agregarUnaCuenta();
                        break;
                    case 2:
                        modificarCuenta();
                        break;
                    case 3:
                        bajaDeCuentas();
                        break;
                    case 4:
                        depositar();
                        break;
                    case 5:
                        retirar();
                        break;
                    case 6:
                        consultar();
                        break;
                    case 7:
                        salir();
                        break;
                    default:
                        continue;
                }
                break;
            case 72:    //Arriba
                if(i>0){
                    i--;
                }else{
                    i = 7;
                }
                break;
            case 80:    //Abajo
                if(i<7){
                    i++;
                }else{
                    i = 0;
                }
                break;
            default:
                cout<<(int)tecla<<endl;
                continue;
        }
    }while(true);

}

void Banco::verListaDeCuentas(){
    cout<<"Salir(q)   -   Av. Pag.(Espacio)   -   Av. Linea(Flecha)"<<endl<<endl;

    for (unsigned int i = 0; i < cuentas.size() ; i++){
        cuentas[i].toString();
        cout<<endl;
    }

    cout<<"verListaDeCuentas()"<<endl;


}

void Banco::agregarUnaCuenta(){
    cout<<"agregarUnaCuenta()"<<endl;
}

void Banco::modificarCuenta(){
    cout<<"modificarCuenta()"<<endl;
}

void Banco::bajaDeCuentas(){
    cout<<"bajaDeCuentas()"<<endl;
}

void Banco::depositar(){
    cout<<"depositar()"<<endl;
}

void Banco::retirar(){
    cout<<"retirar()"<<endl;
}

void Banco::consultar(){
    cout<<"consultar()"<<endl;
}

void Banco::salir(){
    exit(0);
}


bool Banco::leerClientes(ifstream& archivo, Cliente& cliente){
    const int SIZE = 1000;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, '@');
    if (!archivo.good()){
        return false;
    }else{
        long ID = stol(buffer);

        archivo.getline(buffer, SIZE, '@');
        string nombre = buffer;

        archivo.getline(buffer, SIZE, '@');
        string direccion = buffer;

        archivo.getline(buffer, SIZE, '\n');
        string RFC = buffer;

        cliente.leer(ID, nombre, direccion, RFC);

        return true;
    }
}

bool Banco::leerCuentas(ifstream& archivo, Cuenta& cuenta, vector<Cliente>& vectorCliente){
    const int SIZE = 1000;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, '@');
    if (!archivo.good()){
        return false;
    }else{
        long numeroCuenta = stol(buffer);

        archivo.getline(buffer, SIZE, '@');
        long ID_titular = stol(buffer);

        archivo.getline(buffer, SIZE, '\n');
        long double saldo = stold(buffer);

        unsigned int i = 0;
        for (; i < vectorCliente.size(); i++){
            if (vectorCliente[i].getID() == ID_titular){
                break;
            }else{
                continue;
            }
        }

        cuenta.leer(numeroCuenta, vectorCliente[i], saldo);
        return true;
    }
}

bool Banco::leerDebitos(ifstream& archivo, Debito& debito, vector<Cuenta>& vectorCuenta){
    const int SIZE = 1000;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, '@');
    if (!archivo.good()){
        return false;
    }else{
        long numeroCuenta = stol(buffer);

        archivo.getline(buffer, SIZE, '@');
        long maxRet = stol(buffer);

        archivo.getline(buffer, SIZE, '@');
        long resRet = stol(buffer);

        archivo.getline(buffer, SIZE, '\n');
        long depositoMes = stol(buffer);

        unsigned int i = 0;
        for (; i < vectorCuenta.size(); i++){
            if (vectorCuenta[i].getNumeroCuenta() == numeroCuenta){
                break;
            }else{
                continue;
            }
        }

        debito.leer(vectorCuenta[i], maxRet, resRet, depositoMes);

        return true;
    }
}

bool Banco::leerCreditos(ifstream& archivo, Credito& credito, vector<Cuenta>& vectorCuenta){
    const int SIZE = 1000;
    char buffer[SIZE];

    archivo.getline(buffer, SIZE, '@');
    if (!archivo.good()){
        return false;
    }else{
        long numeroCuenta = stol(buffer);

        archivo.getline(buffer, SIZE, '\n');
        long double creditoDis = stold(buffer);

        unsigned int i = 0;
        for (; i < vectorCuenta.size(); i++){
            if (vectorCuenta[i].getNumeroCuenta() == numeroCuenta){
                break;
            }else{
                continue;
            }
        }

        credito.leer(vectorCuenta[i], creditoDis);

        return true;
    }
}
