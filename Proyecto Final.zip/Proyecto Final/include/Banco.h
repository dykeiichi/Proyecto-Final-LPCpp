#ifndef BANCO_H
#define BANCO_H

#include <vector>
#include <fstream>
#include "Cliente.h"
#include "Cuenta.h"
#include "Credito.h"
#include "Debito.h"

class Banco
{
    public:
        Banco();
        ~Banco();
        void menuInicio();
        void verListaDeCuentas();
        void agregarUnaCuenta();
        void modificarCuenta();
        void bajaDeCuentas();
        void depositar();
        void retirar();
        void consultar();
        void salir();

        bool leerClientes(ifstream& archivo, Cliente& cliente);
        bool leerCuentas(ifstream& archivo, Cuenta& cuenta, vector<Cliente>& vectorCliente);
        bool leerDebitos(ifstream& archivo, Debito& debito, vector<Cuenta>& vectorCuenta);
        bool leerCreditos(ifstream& archivo, Credito& credito, vector<Cuenta>& vectorCuenta);
        void agregarCuentaExistente(char & tecla, int & i);
        void agregarCuentaNuevo(char & tecla, int & i);

    protected:

    private:
        vector<Cliente> clientes;
        vector<Cuenta> cuentas;
        vector<Debito> debitos;
        vector<Credito> creditos;

};

#endif // BANCO_H
