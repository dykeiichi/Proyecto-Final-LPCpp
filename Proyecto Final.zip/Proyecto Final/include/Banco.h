#ifndef BANCO_H
#define BANCO_H

#include <vector>
#include <fstream>
#include "Cliente.h"
#include "Cuenta.h"
#include "Credito.h"
#include "Debito.h"
#include "Tiempo.h"

class Banco
{
    public:
        Banco();    //Constructor que lee todo al principio
        ~Banco();   //Destructor que guarda todo al final
        void menuInicio();      //Menu inicio, se repite hasta que se manda a llamar salir();
        /*
            Funciones del menu
        */
        void verListaDeCuentas();
        void agregarUnaCuenta();
        void modificarCuenta();
        void bajaDeCuentas();
        void depositar();
        void retirar();
        void consultar();
        void salir();

        /*
            Funciones que fueron requeridas para que
            las de arriba puedan operar
        */
        bool leerClientes(ifstream& archivo, Cliente& cliente);
        bool leerCuentas(ifstream& archivo, Cuenta& cuenta, vector<Cliente>& vectorCliente);
        bool leerDebitos(ifstream& archivo, Debito& debito, vector<Cuenta>& vectorCuenta);
        bool leerCreditos(ifstream& archivo, Credito& credito, vector<Cuenta>& vectorCuenta);
        void escribirClientes();
        void escribirCuentas();
        void escribirDebitos();
        void escribirCreditos();
        void agregarCuentaExistente(char & tecla, int & i);
        void agregarCuentaNuevo(char & tecla, int & i);
        void recibirDireccion(char &tecla, string &direccion);
        void tipoCuenta(char& tecla, int & i);
        void recibirIDCliente(char& tecla, int& i, long & id_cliente);
        void recibirNumeroCuenta(char& tecla, long & num_cuenta);
        void recibirNombre(char& tecla, int& i, string& nombre);
        void recibirRFC(char& tecla, int& i, string& rfc);
        void escribirNuevasCuentas(char& tecla, int& i, long& id_cliente);
        void recibirCantidadDinero(char& tecla, string& dinero, long double& dineroOut);
        bool leerFechaUltimoMovimiento(ifstream& archivo, Tiempo& tiempo);
        void escribirFechaUltimoMovimiento();
        void validarDepositosDebito();

    protected:

    private:
        /*
            Objetos del banco
            Cada uno se guarda en un archivo diferente
        */
        Tiempo fecha_del_ultimo_deposito;
        vector<Cliente> clientes;
        vector<Cuenta> cuentas;
        vector<Debito> debitos;
        vector<Credito> creditos;

};

#endif // BANCO_H
