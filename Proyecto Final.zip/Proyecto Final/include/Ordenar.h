#ifndef Ordenar_H
#define Ordenar_H
#include <vector>

template <class T>
class Ordenar {
  public:
    void ordenar(vector <T> & vectorArray){
        T aux;
        for(unsigned int i = 0;i < vectorArray.size() ; i++){
            for(unsigned int j = 0;j < (vectorArray.size() - 1); j++){
                if(vectorArray[j] > vectorArray[j+1]){
                    aux = vectorArray[j];
                    vectorArray[j] = vectorArray[j+1];
                    vectorArray[j+1] = aux;
                }
            }
        }
    }
};

#endif // Ordenar_H
