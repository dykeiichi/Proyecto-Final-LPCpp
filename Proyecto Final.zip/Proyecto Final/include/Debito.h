#ifndef Debito_H
#define Debito_H

#include <iostream>
#include "Cuenta.h"

using namespace std;

class Debito : public Cuenta {

private :
    //Variables
    const int _retiro_max = 6500;

public:
    //funciones
    Debito(){}
    Debito(string nombre,long double saldo,string direccion,string RFC):Cuenta(nombre, saldo, direccion, RFC){}
    void retirar(long double val);

};

#endif // Debito
