#ifndef Debito_H
#define Debito_H

#include <iostream>
#include <string>
#include "Cuenta.h"

using namespace std;

class Debito : public Cuenta {

    private :
        //Variables
        double retiroMaximo = 0;
        double retiroRestante = 0;
        double depositoMes = 0;

    public:
        //funciones
        Debito(){}
        Debito(Cuenta &val1, double retiroMaximo = 6500):Cuenta(val1.getNumeroCuenta(), val1.getTitular(), val1.getSaldo(), true){
           this->retiroMaximo = retiroMaximo;
           retiroRestante = retiroMaximo;
        }
        void depositar(long double val);
        void retirar(long double val);
        void setRetiroMaximo(double val){ double aux = val - retiroMaximo; this->retiroMaximo = val; retiroRestante += aux;}

        bool operator<(Debito cr);
        bool operator>(Debito cr);
        bool operator==(Debito cr);
        bool operator<=(Debito cr);
        bool operator>=(Debito cr);
        bool operator!=(Debito cr);

        string guardar(){ return "" + to_string(getNumeroCuenta()) + '@' + to_string(retiroMaximo) + '@' + to_string(retiroRestante) + '@' + to_string(depositoMes) + "\n"; }
        void leer(Cuenta cuenta, double retiroMaximo, double retiroRestante, double depositoMes);

};

#endif // Debito
