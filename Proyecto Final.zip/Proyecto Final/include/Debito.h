#ifndef Debito_H
#define Debito_H

#include <iostream>
#include <string>
#include "Cuenta.h"

using namespace std;

class Debito : public Cuenta {

    private :
        //Variables
        double retiroMaximo = 0;
        double retiroRestante = 0;
        double depositoMes = 0;
        int dia = 0;
        int mes = 0;
        int anio = 0;

    public:
        //funciones
        Debito();
        Debito(Cuenta &val1, double retiroMaximo = 6500);
        void depositar(long double val);
        void retirar(long double val);
        void setRetiroMaximo(double val);
        double getRetiroMaximo();
        double getRetiroRestante();
        double getDepositoMes();
        void restart();

        string guardar();   //regresa la cadena de caracteres que se enviara al archvio
        void leer(Cuenta cuenta, double retiroMaximo, double retiroRestante, double depositoMes, int dia, int mes, int anio);   //con los datos ingresados crea un Debito
        void validarRetiro();

        bool operator<(Debito cr);
        bool operator>(Debito cr);
        bool operator==(Debito cr);
        bool operator<=(Debito cr);
        bool operator>=(Debito cr);
        bool operator!=(Debito cr);
};

#endif // Debito

    ostream& operator<<(ostream& os, Debito de);       //Operador << para imprimir la informacion
