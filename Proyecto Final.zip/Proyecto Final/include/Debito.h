#ifndef DEBITO_H
#define DEBITO_H


class Debito
{
    public:
        Debito();

    protected:

    private:
};

#endif // DEBITO_H
