#ifndef SERIALIZACION_H
#define SERIALIZACION_H
#include <stdio.h>
#include <fstream>
#include <vector>

using namespace std;

template <class T>
class Serializacion {
  public:
    void guardar(vector<T> * matriz, string archivo){

    }

    void leer(vector<T> * matriz, char archivo[30]){
        T aux;
        FILE * archivo_out = fopen(archivo, "rb");
        for (unsigned int i = 0; i<3 ; i++){
            fread(&aux, 100, 1 , archivo_out);
            cout<<i<<"c"<<endl;
            aux.verInformacion();
            matriz->push_back(aux);
            cout<<i<<"d"<<endl;
        }
        fclose(archivo_out);
    }

};

#endif // SERIALIZACION_H
