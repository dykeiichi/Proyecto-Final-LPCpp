#ifndef CLIENTE_H
#define CLIENTE_H

#include <iostream>
#include <string>

using namespace std;

class Cliente
{
    public:
        Cliente();
        Cliente(string nombre, string direccion, string RFC);

        long getVal(){ return val; }
        void setVal() { val++; }
        long getID(){ return ID;}
        void setID(){ ID = val;}
        string getNombre() { return nombre; }
        void setNombre(string val) { nombre = val; }
        string getDireccion() { return direccion; }
        void setDireccion(string val) { direccion = val; }
        string getRFC() { return RFC; }
        void setRFC(string val) { RFC = val; }
        void verInformacion();

        bool operator<(Cliente cl);
        bool operator>(Cliente cl);
        bool operator==(Cliente cl);
        bool operator<=(Cliente cl);
        bool operator>=(Cliente cl);
        bool operator!=(Cliente cl);

        string guardar(){ return "" + to_string(ID) + '@' + nombre + '@' + direccion + '@' + RFC + "\n"; }
        void leer(long ID, string nombre, string direccion, string RFC);

        void setThis(Cliente ThisCliente);


    protected:

    private:
        static long val;
        long ID;
        string nombre;
        string direccion;
        string RFC;
};

#endif // CLIENTE_H
