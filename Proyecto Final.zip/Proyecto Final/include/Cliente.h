#ifndef CLIENTE_H
#define CLIENTE_H

#include <iostream>
using namespace std;

class Cliente
{
    public:
        Cliente();
        Cliente(string nombre, string direccion, string RFC);

        long getVal(){ return val; }
        void setVal() { val++; }
        long getID(){ return ID;}
        string getNombre() { return nombre; }
        void setNombre(string val) { nombre = val; }
        string getDireccion() { return direccion; }
        void setDireccion(string val) { direccion = val; }
        string getRFC() { return RFC; }
        void setRFC(string val) { RFC = val; }
        void verInformacion();
        void guardar(ofstream& salida);
        bool leer(ifstream& archivo);
        bool leer(long id_In);


    protected:

    private:
        static long val;
        long ID = val;
        string nombre;
        string direccion;
        string RFC;
        friend class Cuenta;
};

#endif // CLIENTE_H
