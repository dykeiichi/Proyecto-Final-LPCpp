#ifndef CLIENTE_H
#define CLIENTE_H

#include <iostream>
#include <string>

using namespace std;

class Cliente
{
    public:
        Cliente();
        Cliente(string nombre, string direccion, string RFC);

        long getVal();
        void setVal();
        void setVal(long val1);
        long getID();
        void setID();
        string getNombre();
        void setNombre(string val);
        string getDireccion();
        void setDireccion(string val);
        string getRFC();
        void setRFC(string val);
        void verInformacion();

        bool operator<(Cliente cl);
        bool operator>(Cliente cl);
        bool operator==(Cliente cl);
        bool operator<=(Cliente cl);
        bool operator>=(Cliente cl);
        bool operator!=(Cliente cl);

        string guardar();   //regresa la cadena de caracteres que se enviara al archvio
        void leer(long ID, string nombre, string direccion, string RFC);    //con los datos ingresados crea un Cliente

        void setThis(Cliente ThisCliente);  //Copia un cliente, necesario para acceder desde clases heredadas como Debito y Credito


    protected:

    private:
        static long val;
        long ID;
        string nombre;
        string direccion;
        string RFC;
};

#endif // CLIENTE_H
