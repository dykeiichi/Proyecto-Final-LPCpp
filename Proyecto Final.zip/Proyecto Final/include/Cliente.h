#ifndef CLIENTE_H
#define CLIENTE_H

#include <iostream>
#include <string>

using namespace std;

class Cliente
{
    public:
        Cliente();
        Cliente(string nombre, string direccion, string RFC);

        long getVal();
        void setVal();
        void setVal(long val1);
        long getID();
        void setID();
        string getNombre();
        void setNombre(string val);
        string getDireccion();
        void setDireccion(string val);
        string getRFC();
        void setRFC(string val);
        void verInformacion();

        bool operator<(Cliente cl);
        bool operator>(Cliente cl);
        bool operator==(Cliente cl);
        bool operator<=(Cliente cl);
        bool operator>=(Cliente cl);
        bool operator!=(Cliente cl);

        string guardar();
        void leer(long ID, string nombre, string direccion, string RFC);

        void setThis(Cliente ThisCliente);


    protected:

    private:
        static long val;
        long ID;
        string nombre;
        string direccion;
        string RFC;
};

#endif // CLIENTE_H
