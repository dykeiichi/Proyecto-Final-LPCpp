#ifndef Cuenta_H
#define Cuenta_H

#include <iostream>
#include <string>
#include <fstream>
#include "Cliente.h"

using namespace std;

class Cuenta {

    private :
        static long numCuenta;
        long numeroCuenta;
        Cliente titular;
        long double saldo = 0;
        bool tipo = 0;  //0 = credito, 1 = debito
        bool activo = 1;    //cuenta activa o inactiva

    protected:
        Cuenta(long val1, Cliente val2, long double val3, bool val4){
            this->numeroCuenta = val1;
            this->titular = val2;
            this->saldo = val3;
            this->tipo = val4;
        }

    public:

        //Constructor de la clase Cuenta
        Cuenta(){}
        Cuenta(long double saldo, Cliente cliente, bool tipo){
            setNumCuenta();
            setNumeroCuenta();
            setSaldo(saldo);
            //Le dice a cliente que lea sus datos del archivo segun su id
            titular.setThis(cliente);
            this->tipo = tipo;
        }
        void setNumCuenta();
        void setNumCuenta(long val1){ numCuenta = val1; }
        long getNumCuenta();
        void setTipo(bool val1 = 0){ this->tipo = val1; }
        bool getTipo(){ return tipo; }
        void setActivo(bool val1 = 1){ this->activo = val1; }
        bool getActivo(){ return activo; }
        void setNumeroCuenta();
        void setNumeroCuenta(long val);
        long getNumeroCuenta();
        Cliente getTitular();
        void setTitular(Cliente cliente){ titular.setThis(cliente); }
        void setSaldo(long double saldoIn);
        long double getSaldo();
        virtual void retirar(long double retiro){}
        virtual void depositar(long double deposito){}
        void setDirecion(string val){ titular.setDireccion(val); }

        bool operator<(Cuenta cu);
        bool operator>(Cuenta cu);
        bool operator==(Cuenta cu);
        bool operator<=(Cuenta cu);
        bool operator>=(Cuenta cu);
        bool operator!=(Cuenta cu);
        bool operator<<(Cuenta cu);

        string guardar();
        void leer(long numeroCuenta, Cliente titular, long double saldo, bool tipo, bool activo);

        void toString();
        void saldoToString();

};

#endif // Cuenta

    ostream& operator<<(ostream& os, Cuenta cu);
