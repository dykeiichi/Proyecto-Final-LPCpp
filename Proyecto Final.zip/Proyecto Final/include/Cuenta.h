#ifndef CUENTA_H
#define CUENTA_H


class Cuenta
{
    public:
        Cuenta();

    protected:

    private:
};

#endif // CUENTA_H
