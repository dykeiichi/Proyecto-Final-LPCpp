#ifndef Cuenta_H
#define Cuenta_H

#include <iostream>
#include "Cliente.h"

using namespace std;

class Cuenta{

private :
    static long val;
    long numCuenta = val;
    Cliente titular;
    long double saldo = 0;
    friend class Credito;
    friend class Debito;


public:

    //Constructor de la clase Cuenta
    Cuenta(){}
    Cuenta(long id,long double saldo){
        setVal();
        setSaldo(saldo);
        //Llama al constructor de Cliente
        setTitular(id);
    }
    void setVal();
    long getVal();
    long getNumCuenta();
    void setTitular(long id);
    Cliente getTitular();
    void setSaldo(long double saldoIn);
    long double getSaldo();
    void retirar(long double retiro);
    void depositar(long double deposito);
    void toString();
    void saldoToString();

};

#endif // Cuenta
