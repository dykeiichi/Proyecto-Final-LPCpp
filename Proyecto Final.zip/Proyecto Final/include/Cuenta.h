#ifndef Cuenta_H
#define Cuenta_H

#include <iostream>
#include <string>
#include <fstream>
#include "Cliente.h"

using namespace std;

class Cuenta {

    private :
        static long numCuenta;
        long numeroCuenta;
        Cliente titular;
        long double saldo = 0;
        bool tipo = 0;  //0 = credito, 1 = debito
        bool activo = 1;    //cuenta activa o inactiva

    protected:
        Cuenta(long val1, Cliente val2, long double val3, bool val4);

    public:

        //Constructor de la clase Cuenta
        Cuenta();
        Cuenta(long double saldo, Cliente cliente, bool tipo);
        void setNumCuenta();
        void setNumCuenta(long val1);
        long getNumCuenta();
        void setTipo(bool val1 = 0);
        bool getTipo();
        void setActivo(bool val1 = 1);
        bool getActivo();
        void setNumeroCuenta();
        void setNumeroCuenta(long val);
        long getNumeroCuenta();
        Cliente getTitular();
        void setTitular(Cliente cliente);
        void setSaldo(long double saldoIn);
        long double getSaldo();
        virtual void retirar(long double retiro){}
        virtual void depositar(long double deposito){}
        void setDirecion(string val);
        void toString();
        void saldoToString();

        string guardar();   //regresa la cadena de caracteres que se enviara al archvio
        void leer(long numeroCuenta, Cliente titular, long double saldo, bool tipo, bool activo);   //con los datos ingresados crea una Cuenta

        bool operator<(Cuenta cu);
        bool operator>(Cuenta cu);
        bool operator==(Cuenta cu);
        bool operator<=(Cuenta cu);
        bool operator>=(Cuenta cu);
        bool operator!=(Cuenta cu);
        bool operator<<(Cuenta cu);
};

#endif // Cuenta

    ostream& operator<<(ostream& os, Cuenta cu);       //Operador << para imprimir la informacion
