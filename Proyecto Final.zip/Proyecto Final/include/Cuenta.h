#ifndef Cuenta_H
#define Cuenta_H

#include <iostream>
#include <string>
#include "Cliente.h"

using namespace std;

class Cuenta {

private :
    static long numCuenta;
    long numeroCuenta;
    Cliente titular;
    long double saldo = 0;

protected:
    Cuenta(long val1, Cliente val2, long double val3){
        this->numeroCuenta = val1;
        this->titular = val2;
        this->saldo = val3;
    }

public:

    //Constructor de la clase Cuenta
    Cuenta(){}
    Cuenta(long double saldo, Cliente cliente){
        setNumCuenta();
        setNumeroCuenta();
        setSaldo(saldo);
        //Le dice a cliente que lea sus datos del archivo segun su id
        titular.setThis(cliente);
    }
    void setNumCuenta();
    long getNumCuenta();
    void setNumeroCuenta();
    void setNumeroCuenta(long val);
    long getNumeroCuenta();
    Cliente getTitular();
    void setTitular(Cliente cliente){ titular.setThis(cliente); }
    void setSaldo(long double saldoIn);
    long double getSaldo();
    virtual void retirar(long double retiro){}
    virtual void depositar(long double deposito){}
    string guardar(){ return "" + to_string(getNumeroCuenta()) + '@' + to_string(titular.getID()) + '@' + to_string(saldo) + "\n"; }
    void leer(long numeroCuenta, Cliente titular, long double saldo);
    void toString();
    void saldoToString();

};

#endif // Cuenta
