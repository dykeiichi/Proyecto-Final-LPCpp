#ifndef Credito_H
#define Credito_H

#include <iostream>
#include "Cuenta.h"
#include <string>

using namespace std;

class Credito : public Cuenta {

private :
    //Variables
    long double _credito_disponible = 0;

public:
    //funciones
    Credito(){}
    Credito(Cuenta cuenta, long creditoDis):Cuenta(cuenta.getNumeroCuenta(), cuenta.getTitular(), cuenta.getSaldo()){
       _credito_disponible = creditoDis;
    }
    void depositar(long double val);
    void retirar(long double val);
    void setThis(Credito ThisCredito);
    string guardar(){ return "" + to_string(getNumeroCuenta()) + '@' + to_string(_credito_disponible) + "\n"; }
    void leer(Cuenta cuenta, long double creditoDis);

};

#endif // Credito
