#ifndef Credito_H
#define Credito_H

#include <iostream>
#include "Cuenta.h"
#include <string>

using namespace std;

class Credito : public Cuenta {

    private :
        //Variables
        long double _credito_disponible = 0;

    public:
        //funciones
        Credito(){this->setTipo(false); }
        Credito(Cuenta &val1, long creditoDis = 50000):Cuenta(val1.getNumeroCuenta(), val1.getTitular(), val1.getSaldo(), false){
           _credito_disponible = creditoDis;
        }
        void set_Credito_Maximo(long double val){ _credito_disponible = val + getSaldo(); }
        long double get_Credito_Disponible(){ return _credito_disponible; }
        void depositar(long double val);
        void retirar(long double val);

        bool operator<(Credito cr);
        bool operator>(Credito cr);
        bool operator==(Credito cr);
        bool operator<=(Credito cr);
        bool operator>=(Credito cr);
        bool operator!=(Credito cr);

        string guardar(){ return "" + to_string(getNumeroCuenta()) + '@' + to_string(_credito_disponible) + "\n"; }
        void leer(Cuenta cuenta, long double creditoDis);

};

#endif // Credito
