#ifndef Credito_H
#define Credito_H

#include <iostream>
#include "Cuenta.h"

using namespace std;

class Credito : public Cuenta{

private :
    //Variables
    const int limiteCredito = 50000;
    int _credito_disponible = limiteCredito + getSaldo();

public:
    //funciones
    Credito(){}
    Credito(long val1){ numCuenta = val1;}
    void depositar(long double val);
    void retirar(long double val);
    void toString();

};

#endif // Credito
