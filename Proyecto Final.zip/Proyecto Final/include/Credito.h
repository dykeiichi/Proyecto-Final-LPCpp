#ifndef Credito_H
#define Credito_H

#include <iostream>
#include "Cuenta.h"
#include <string>

using namespace std;

class Credito : public Cuenta {

    private :
        //Variables
        long double _credito_disponible = 0;

    public:
        //funciones
        Credito();
        Credito(Cuenta &val1, long creditoDis = 50000);
        void set_Credito_Maximo(long double val);
        long double get_Credito_Disponible();
        void depositar(long double val);
        void retirar(long double val);

        bool operator<(Credito cr);
        bool operator>(Credito cr);
        bool operator==(Credito cr);
        bool operator<=(Credito cr);
        bool operator>=(Credito cr);
        bool operator!=(Credito cr);

        string guardar();   //regresa la cadena de caracteres que se enviara al archvio
        void leer(Cuenta cuenta, long double creditoDis);   //con los datos ingresados crea un Credito

};

#endif // Credito

    ostream& operator<<(ostream& os, Credito cr);       //Operador << para imprimir la informacion
