#ifndef CREDITO_H
#define CREDITO_H


class Credito
{
    public:
        Credito();

    protected:

    private:
};

#endif // CREDITO_H
