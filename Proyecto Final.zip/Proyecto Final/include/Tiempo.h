#ifndef TIEMPO_H
#define TIEMPO_H

#include <iostream>

using namespace std;

class Tiempo
{
    public:
        Tiempo();
        Tiempo (int anio, int mes, int dia, int hora, int minutos, int segundos, int milisegundos);
        int getAnio();
        int getMes();
        int getDia();
        int getHora();
        int getMinutos();
        int getSegundos();
        int getMilisegundos();
        Tiempo operator+(Tiempo);
        Tiempo operator-(Tiempo);
        operator long long();
        Tiempo operator++();
        Tiempo operator++(int);
        Tiempo operator--();
        Tiempo operator--(int);

    protected:

    private:

        int dia;
        int mes;
        int anio;
        int hora;
        int minutos;
        int segundos;
        int milisegundos;
};

    ostream& operator<<(ostream&, Tiempo);

#endif // TIEMPO_H
